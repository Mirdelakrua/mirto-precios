<?php
/*
 * GENERADOR DEL SITIO
 * Se ejecuta con el cron de cPanel (recomendado: cada 2 horas):
 *     /usr/local/bin/php /home/TU_USUARIO/generador/cron.php
 *
 * Opciones:
 *     --forzar   ignora la caché y vuelve a descargar todos los datos
 *     --todo     publica todas las páginas de una vez (sin publicación gradual)
 */

$GLOBALS['CFG'] = require __DIR__ . '/config.php';
// Para pruebas locales se pueden pisar rutas con variables de entorno
foreach (['MODO_PRUEBA' => 'modo_prueba', 'SALIDA' => 'salida', 'DATOS' => 'datos'] as $env => $k) {
    if (getenv($env)) $GLOBALS['CFG'][$k] = getenv($env);
}
date_default_timezone_set($GLOBALS['CFG']['zona_horaria']);
set_time_limit(600);
ini_set('memory_limit', '1024M');

foreach (['util', 'graficos', 'render', 'noticias', 'vtv', 'telegram'] as $f) require __DIR__ . '/lib/' . $f . '.php';
foreach (['inicio', 'provincias', 'herramientas', 'guias', 'guias_extra', 'noticias'] as $f) require __DIR__ . '/secciones/' . $f . '.php';

$args = isset($argv) ? $argv : [];
$GLOBALS['FORZAR'] = in_array('--forzar', $args, true);
$todo = in_array('--todo', $args, true);

asegurar_carpeta(cfg('datos'));
asegurar_carpeta(cfg('salida'));
$lock = fopen(cfg('datos') . '/cron.lock', 'c');
if (!flock($lock, LOCK_EX | LOCK_NB)) {
    registrar_log('Ya hay una ejecución en curso, salgo.');
    exit(0);
}

$t0 = microtime(true);
vtv_sincronizar_remoto();
$D = vtv_cargar();
telegram_procesar($D);   // aprobaciones pendientes de precios (si hay bot configurado)
$estado = [];
foreach ($D['fuentes'] as $k => $v) $estado[] = "$k=$v";
registrar_log('Datos: ' . implode(', ', $estado));

seccion_inicio($D);
seccion_provincias($D);
seccion_herramientas($D);
seccion_guias($D);
seccion_guias_extra($D);

$pendientes = calcular_publicadas($todo);
// Noticias: primero se redactan las nuevas (si hay API configurada) y después se registran todas
vtv_revisar_precios($D);   // una vez por semana: busca aumentos con la API y pide aprobación por Telegram
seccion_noticias($D);
$pendientes = calcular_publicadas($todo);

// ---------- Archivos fijos ----------
$salida = cfg('salida');
foreach (['app.js', 'favicon.svg', 'favicon.ico', 'favicon-32.png', 'apple-touch-icon.png', 'icon-192.png', 'icon-512.png', 'img/og.png', 'img/logo.png'] as $a) {
    $origen = __DIR__ . '/assets/' . $a;
    if (is_file($origen)) {
        asegurar_carpeta(dirname($salida . '/' . $a));
        copy($origen, $salida . '/' . $a);
    }
}
escribir_archivo($salida . '/img/logo.svg', logo_svg());
escribir_archivo($salida . '/img/logo-oscuro.svg', logo_svg(true));
escribir_archivo($salida . '/site.webmanifest', json_encode([
    'name' => cfg('sitio_nombre'), 'short_name' => cfg('sitio_nombre'), 'description' => cfg('sitio_lema'), 'lang' => 'es-AR',
    'start_url' => '/', 'display' => 'browser', 'background_color' => '#ffffff', 'theme_color' => '#1d4ed8',
    'icons' => [['src' => '/icon-192.png', 'sizes' => '192x192', 'type' => 'image/png'], ['src' => '/icon-512.png', 'sizes' => '512x512', 'type' => 'image/png'],
        ['src' => '/favicon.svg', 'sizes' => 'any', 'type' => 'image/svg+xml']],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));

// ---------- Páginas ----------
$manifiesto_ant = leer_json(cfg('datos') . '/manifiesto.json', []);
$manifiesto = [];
$imagenes = [];
$errores = 0;
// El mapa del sitio se arma al final, con los títulos de todas las páginas ya generadas
$orden = $GLOBALS['PUBLICADAS'];
if (isset($orden['/mapa-del-sitio/'])) { $fm = $orden['/mapa-del-sitio/']; unset($orden['/mapa-del-sitio/']); $orden['/mapa-del-sitio/'] = $fm; }
$GLOBALS['TITULOS'] = [];
foreach ($orden as $path => $fecha) {
    $reg = $GLOBALS['PAGINAS'][$path];
    try {
        $GLOBALS['IMGS_PAGINA'] = [];
        $p = call_user_func($reg['fn']);
        if (isset($p['cuerpo'])) $p['cuerpo'] = reescribir_enlaces_loc($p['cuerpo']);
        $p['path'] = $path;
        $p['publicada'] = $fecha;
        escribir_archivo($salida . $path . 'index.html', pagina_html($p));
        $GLOBALS['TITULOS'][$path] = $p['h1'] ?? $p['title'];
        $manifiesto[$path] = $reg['seccion'];
        $imagenes[$path] = $GLOBALS['IMGS_PAGINA'];
    } catch (Throwable $ex) {
        $errores++;
        registrar_log("ERROR en $path: " . $ex->getMessage() . ' (' . basename($ex->getFile()) . ':' . $ex->getLine() . ')');
        if (isset($manifiesto_ant[$path])) $manifiesto[$path] = $manifiesto_ant[$path];
    }
}

// Borrar páginas que ya no existen (sólo si su sección se cargó bien en esta corrida)
$secciones_ok = ['inicio' => true];
foreach ($D['ok'] as $k => $v) if ($v) $secciones_ok[$k] = true;
foreach ($manifiesto_ant as $path => $sec) {
    if (isset($manifiesto[$path]) || !isset($secciones_ok[$sec]) || $path === '/') continue;
    @unlink($salida . $path . 'index.html');
    @rmdir($salida . $path);
    registrar_log("Página eliminada: $path");
}
guardar_json(cfg('datos') . '/manifiesto.json', $manifiesto);

// ---------- 404, sitemap, robots, .htaccess, ads.txt ----------
$p404 = ['path' => '/404.html', 'noindex' => true, 'title' => 'Página no encontrada | ' . cfg('sitio_nombre'), 'h1' => 'No encontramos esta página',
    'desc' => 'La página que buscás no existe.', 'cuerpo' => '<p class="intro">Puede que la dirección haya cambiado. Estas son las secciones del sitio:</p><ul class="lista-enlaces">'
        . implode('', array_map(function ($p, $t) { return publicada($p) ? '<li><a href="' . $p . '">' . e($t) . '</a></li>' : ''; }, array_keys(menu_principal()), menu_principal())) . '</ul>'];
escribir_archivo($salida . '/404.html', pagina_html($p404));

$xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
foreach ($manifiesto as $path => $sec) {
    $estatica = $sec === 'inicio' && $path !== '/';
    $lastmod = $estatica ? $GLOBALS['PUBLICADAS'][$path] : hoy();
    $img = '';
    foreach (($imagenes[$path] ?? []) as $im) $img .= '<image:image><image:loc>' . e(url_abs($im[0])) . '</image:loc></image:image>';
    $xml .= '<url><loc>' . e(url_abs($path)) . '</loc><lastmod>' . $lastmod . '</lastmod>' . $img . '</url>' . "\n";
}
$xml .= '</urlset>';
escribir_archivo($salida . '/sitemap.xml', $xml);
$llms = '# ' . cfg('sitio_nombre') . "\n\n> " . cfg('llms_resumen') . "\n\nAl citar un dato, incluí la URL de la página y la fecha de actualización que figura en ella.\n\n## Secciones principales\n\n";
foreach (cfg('llms_secciones', []) as $lp => $lt) {
    if (isset($manifiesto[$lp])) $llms .= '- [' . $lt . '](' . url_abs($lp) . ")\n";
}
$llms .= "\n## Todas las páginas\n\n- [Mapa del sitio](" . url_abs('/mapa-del-sitio/') . ")\n- [Sitemap XML](" . url_abs('/sitemap.xml') . ")\n";
escribir_archivo($salida . '/llms.txt', $llms);
escribir_archivo($salida . '/sitemap-noticias.xml', sitemap_noticias());
escribir_archivo($salida . '/robots.txt', "User-agent: *\nAllow: /\nDisallow: /ir/\n\nSitemap: " . url_abs('/sitemap.xml') . "\nSitemap: " . url_abs('/sitemap-noticias.xml') . "\n");
if (cfg('adsense_client')) {
    escribir_archivo($salida . '/ads.txt', 'google.com, ' . str_replace('ca-', '', cfg('adsense_client')) . ", DIRECT, f08c47fec0942fa0\n");
}
escribir_htaccess($salida . '/.htaccess');

registrar_log(sprintf('Listo: %d páginas publicadas, %d pendientes de publicar, %d errores, %.1f s', count($manifiesto), $pendientes, $errores, microtime(true) - $t0));
flock($lock, LOCK_UN);

// ---------- Auxiliares ----------

function logo_svg($oscuro = false)
{
    $nombre = cfg('sitio_nombre');
    $res = (string) cfg('logo_resalte', '');
    if ($res !== '' && substr($nombre, -strlen($res)) === $res && strlen($nombre) > strlen($res)) {
        $partes = [substr($nombre, 0, -strlen($res)), $res];
    } else {
        $partes = preg_split('/(?<=\p{Ll})(?=\p{Lu})/u', $nombre, 2);
    }
    $largo = function_exists('mb_strlen') ? mb_strlen($nombre, 'UTF-8') : strlen($nombre);
    $W = 52 + (int) ceil($largo * 14);
    $texto = '<tspan fill="' . ($oscuro ? '#e8eef5' : '#0f172a') . '">' . svg_esc($partes[0]) . '</tspan>' . (isset($partes[1]) ? '<tspan fill="' . ($oscuro ? '#7aa2ff' : '#1d4ed8') . '">' . svg_esc($partes[1]) . '</tspan>' : '');
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $W . ' 36" width="' . $W . '" height="36"><title>' . svg_esc($nombre) . '</title>'
        . '<rect width="36" height="36" rx="9" fill="#1d4ed8"/><path d="M6.5 23.2 8.6 17.2C9.1 15.8 10.3 15 11.7 15H21.3C22.7 15 23.9 15.8 24.4 17.2L26.5 23.2V26.6H6.5Z" fill="#fff"/><path d="M10.9 21 12.2 17.6C12.4 17.1 12.8 16.9 13.3 16.9H19.7C20.2 16.9 20.6 17.1 20.8 17.6L22.1 21Z" fill="#1d4ed8"/><circle cx="11" cy="26.6" r="2.7" fill="#0f172a" stroke="#fff" stroke-width="1.2"/><circle cx="22" cy="26.6" r="2.7" fill="#0f172a" stroke="#fff" stroke-width="1.2"/><circle cx="27.6" cy="9.6" r="5.6" fill="#fbbf24"/><polyline points="25,9.7 27,11.7 30.3,7.9" fill="none" stroke="#0f172a" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>'
        . '<text x="46" y="25.5" font-family="system-ui,-apple-system,Segoe UI,Roboto,sans-serif" font-size="20" font-weight="800" letter-spacing="-0.3">' . $texto . '</text></svg>';
}

function escribir_htaccess($ruta)
{
    $host = parse_url(cfg('sitio_url'), PHP_URL_HOST);
    $con_www = strpos($host, 'www.') === 0;
    // Links de referido enmascarados: /ir/clave/ redirige al link real (el código no aparece en el HTML)
    $redir = '';
    foreach (cfg('referidos', []) as $k => $r) {
        if (!empty($r['vence']) && hoy() > $r['vence']) continue;
        if (!empty($r['url']) && preg_match('#^https://[^\s"]+$#', $r['url'])) $redir .= 'RewriteRule ^ir/' . preg_quote($k) . '/?$ ' . str_replace('%', '\\%', $r['url']) . " [R=302,L,NE]\n";
    }
    // Localidades fusionadas en la página de su provincia: 301 a su sección
    foreach (($GLOBALS['REDIR_LOC'] ?? []) as $de => $a) {
        if (preg_match('#^/[a-z0-9-]+/$#', $de) && preg_match('#^/[a-z0-9-]+/\#[a-z0-9-]+$#', $a)) $redir .= 'RewriteRule ^' . trim($de, '/') . '/?(index\.html)?$ ' . $a . " [R=301,L,NE]\n";
    }
    $bloque = "# BEGIN generador-sitio\n"
        . "Options -Indexes\nDirectoryIndex index.html index.php\nErrorDocument 404 /404.html\n"
        . "<IfModule mod_rewrite.c>\nRewriteEngine On\n"
        . "RewriteCond %{HTTPS} off\nRewriteCond %{HTTP:X-Forwarded-Proto} !https\nRewriteRule ^(.*)$ https://" . $host . "/$1 [R=301,L]\n"
        . ($con_www
            ? "RewriteCond %{HTTP_HOST} !^www\\. [NC]\nRewriteRule ^(.*)$ https://" . $host . "/$1 [R=301,L]\n"
            : "RewriteCond %{HTTP_HOST} ^www\\.(.+)$ [NC]\nRewriteRule ^(.*)$ https://" . $host . "/$1 [R=301,L]\n")
        . $redir
        . "</IfModule>\n"
        . "<IfModule mod_deflate.c>\nAddOutputFilterByType DEFLATE text/html text/css application/javascript image/svg+xml application/json application/xml text/xml text/plain\n</IfModule>\n"
        . "AddType application/manifest+json .webmanifest\nAddType image/x-icon .ico\n"
        . "<IfModule mod_expires.c>\nExpiresActive On\nExpiresByType text/html \"access plus 5 minutes\"\nExpiresByType application/javascript \"access plus 1 year\"\n"
        . "ExpiresByType image/svg+xml \"access plus 1 day\"\nExpiresByType image/png \"access plus 1 month\"\nExpiresByType image/x-icon \"access plus 1 month\"\nExpiresByType application/manifest+json \"access plus 1 week\"\n</IfModule>\n"
        . "<IfModule mod_headers.c>\n<FilesMatch \"\\.(js)$\">\nHeader set Cache-Control \"public, max-age=31536000, immutable\"\n</FilesMatch>\n<FilesMatch \"\\.(html)$\">\nHeader set Cache-Control \"public, max-age=1800\"\n</FilesMatch>\nHeader always set X-Content-Type-Options \"nosniff\"\nHeader always set Referrer-Policy \"strict-origin-when-cross-origin\"\n</IfModule>\n"
        . "# END generador-sitio\n";
    $actual = is_file($ruta) ? file_get_contents($ruta) : '';
    $actual = preg_replace('/# BEGIN generador-sitio.*?# END generador-sitio\n?/s', '', $actual);
    escribir_archivo($ruta, $bloque . $actual);
}
