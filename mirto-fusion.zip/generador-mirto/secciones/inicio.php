<?php
// Portada, páginas institucionales y mapa del sitio.

function seccion_inicio($D)
{
    registrar('/', 0, 'inicio', function () use ($D) { return inicio($D); });
    foreach (['acerca', 'fuentes', 'privacidad', 'terminos', 'contacto'] as $p) {
        $pag = $p;
        registrar('/' . $p . '/', 0, 'inicio', function () use ($pag, $D) { return call_user_func('legal_' . $pag, $D) + ['sin_aviso_legal' => true]; });
    }
    registrar('/mapa-del-sitio/', 0, 'inicio', 'mapa_del_sitio');
}

function provincia_path($p)
{
    return '/' . strtolower($p['sigla']) . '-' . $p['slug'] . '/';
}

function tarjeta($path, $etq, $valor, $nota)
{
    $dentro = '<span class="tarjeta-etq">' . e($etq) . '</span><strong class="tarjeta-val">' . $valor . '</strong><span class="tarjeta-nota">' . $nota . '</span>';
    return publicada($path) ? '<a class="tarjeta" href="' . e($path) . '">' . $dentro . '</a>' : '<div class="tarjeta">' . $dentro . '</div>';
}

function inicio($D)
{
    $P = $D['provincias'];
    $c = '<h2 class="sin-margen">Cuánto cuesta la VTV de un auto en cada provincia</h2>'
        . '<p>De la más cara a la más barata, con el precio vigente para un auto particular. ' . enlace('/precio-vtv/', 'Ver motos, camionetas y pesados') . '.</p>'
        . ranking_precios($P);
    $c .= anuncio('arriba');
    $c .= '<h2>Dónde hacer la VTV: plantas por ciudad</h2><p>Dirección, horarios y cómo llegar a cada planta habilitada. ' . enlace('/plantas/', 'Ver todas las plantas del país') . '.</p>' . plantas_destacadas($D, 24);
    $c .= '<h2>Antes de ir</h2><ul class="atajos">'
        . '<li><a href="/que-revisan-en-la-vtv/"><strong>¿Pasa mi auto?</strong><span>Checklist de las 23 cosas que revisan, para no rebotar por una lamparita.</span></a></li>'
        . '<li><a href="/documentacion-para-la-vtv/"><strong>Qué llevar</strong><span>DNI, cédula y lo que pide cada provincia.</span></a></li>'
        . '<li><a href="/resultado-de-la-vtv/"><strong>Si te dan condicional</strong><span>Cuántos días tenés para volver y si se paga de nuevo.</span></a></li>'
        . '<li><a href="/multa-por-no-tener-vtv/"><strong>Multas</strong><span>Cuánto te cobran si circulás con la VTV vencida.</span></a></li>'
        . '<li><a href="/vtv-auto-0km/"><strong>VTV de un auto 0 km</strong><span>Cuándo te toca la primera según tu provincia.</span></a></li>'
        . '<li><a href="/perdi-la-oblea-de-la-vtv/"><strong>Perdí la oblea</strong><span>Cómo reponerla y si sirve el certificado digital.</span></a></li></ul>';
    $casos = [['/vtv-moto/', 'Motos', 'Precio por provincia y cada cuánto se hace.'], ['/vtv-camioneta/', 'Camionetas y pick-ups', 'Cuánto más pagan que un auto.'],
        ['/vtv-taxi-y-remis/', 'Taxis y remises', 'Revisión cada 6 o 12 meses y 50% de descuento en PBA.'], ['/cada-cuanto-se-hace-la-vtv/', '¿Anual o cada 2 años?', 'La regla de cada provincia.'],
        ['/vtv-vencida/', 'Se me venció', 'Si la podés hacer igual y si podés circular.'], ['/descuentos-vtv/', 'Descuentos', 'Quién no paga y quién paga la mitad.'],
        ['/vtv-vidrios-polarizados/', 'Vidrios polarizados', 'Cuándo te observan y qué dice la ley.'], ['/vtv-gnc/', 'Autos con GNC', 'Oblea del gas y cilindros al día.']];
    $li = '';
    foreach ($casos as $k) if (publicada($k[0])) $li .= '<li><a href="' . $k[0] . '"><strong>' . e($k[1]) . '</strong><span>' . e($k[2]) . '</span></a></li>';
    if ($li) $c .= '<h2>Según tu vehículo y tu caso</h2><ul class="atajos">' . $li . '</ul>';
    $c .= anuncio('medio');
    $c .= '<h2>VTV, RTO o ITV en tu provincia</h2>' . lista_provincias($P);
    $c .= noticias_bloque_inicio();
    $c .= '<h2>¿Qué es la VTV?</h2><p>La Verificación Técnica Vehicular es el control obligatorio que comprueba que tu vehículo está en condiciones de circular: frenos, luces, dirección, neumáticos, emisiones y elementos de seguridad. '
        . 'Lo exige la Ley Nacional de Tránsito y cada provincia la implementa con su propio nombre (VTV, RTO, ITV o RTV), sus precios y sus plantas habilitadas. '
        . 'Si aprobás, te dan una oblea que tenés que llevar pegada en el parabrisas.</p>';
    $faqs = [];
    if (isset($P['buenos-aires'])) $faqs[] = ['¿Cuánto cuesta la VTV en la provincia de Buenos Aires?', 'Para un auto particular, ' . pesos_vtv(vtv_precio($P['buenos-aires'])) . ' (vigente desde ' . fecha_corta($P['buenos-aires']['vigencia_desde']) . ').'];
    if (isset($P['caba'])) $faqs[] = ['¿Cuánto cuesta la VTV en CABA?', 'Para un auto particular, ' . pesos_vtv(vtv_precio($P['caba'])) . ' (vigente desde ' . fecha_corta($P['caba']['vigencia_desde']) . ').'];
    $faqs[] = ['¿MiRTO es un sitio oficial?', 'No. Es una guía independiente: no damos turnos ni hacemos verificaciones. Los turnos se sacan en el sitio oficial de cada provincia, que enlazamos en cada página.'];
    return ['title' => 'VTV, RTO e ITV: precios, vencimientos y plantas | MiRTO',
        'h1' => 'VTV: cuándo te toca, cuánto cuesta y dónde hacerla',
        'desc' => 'Cuánto cuesta la VTV, RTO o ITV en cada provincia, cuándo te vence según la patente, qué revisan, qué llevar y dónde están las plantas.',
        'cuerpo' => $c, 'faqs' => $faqs, 'js' => true, 'hero' => hero_inicio($D)];
}

function lista_provincias($P)
{
    $h = '<ul class="provincias">';
    foreach ($P as $p) {
        $h .= '<li><span class="pv-sigla">' . e($p['sigla']) . '</span><span class="pv-nom">' . enlace(provincia_path($p), $p['nombre']) . '</span><span class="pv-precio">' . pesos_vtv(vtv_precio($p)) . '</span></li>';
    }
    return $h . '</ul>';
}

function mapa_del_sitio()
{
    $grupos = [];
    foreach ($GLOBALS['TITULOS'] as $path => $tit) {
        if (preg_match('#^/(vtv|rto|itv|rtv|rtop?)-#', $path) && substr_count($path, '/') === 2) $g = 'Provincias';
        elseif (preg_match('#^/(vtv|rto|itv|rtv)-#', $path)) $g = 'Plantas por localidad';
        elseif (strpos($path, '/noticias/') === 0) $g = 'Noticias';
        elseif (in_array($path, ['/acerca/', '/fuentes/', '/privacidad/', '/terminos/', '/contacto/', '/'], true)) $g = cfg('sitio_nombre');
        else $g = 'Guías y herramientas';
        $grupos[$g][$path] = $tit;
    }
    $c = '<p class="intro">Todas las páginas de ' . e(cfg('sitio_nombre')) . '. También está el <a href="/sitemap.xml">sitemap XML</a> para buscadores.</p>';
    foreach (['Guías y herramientas', 'Provincias', 'Plantas por localidad', 'Noticias', cfg('sitio_nombre')] as $g) {
        if (empty($grupos[$g])) continue;
        $c .= '<h2>' . e($g) . '</h2><ul class="mapa">';
        foreach ($grupos[$g] as $path => $tit) $c .= '<li><a href="' . e($path) . '">' . e($tit) . '</a></li>';
        $c .= '</ul>';
    }
    return ['title' => 'Mapa del sitio | ' . cfg('sitio_nombre'), 'h1' => 'Mapa del sitio', 'desc' => 'Todas las páginas de MiRTO: precios de la VTV, vencimientos, provincias, plantas, guías y noticias.', 'cuerpo' => $c, 'sin_aviso_legal' => true];
}

function legal_acerca($D)
{
    $c = '<p class="intro">MiRTO es una guía argentina <strong>independiente</strong> sobre la verificación técnica vehicular. Reunimos en un solo lugar los precios, vencimientos, requisitos y plantas de todas las provincias, que normalmente están dispersos en decenas de sitios oficiales.</p>'
        . '<h2>Qué no somos</h2><p>No somos un organismo oficial, una planta de verificación ni un gestor. No damos turnos, no cobramos la VTV y no intermediamos en ningún trámite. Para sacar turno siempre te enviamos al sitio oficial de tu provincia.</p>'
        . '<h2>Cómo mantenemos los datos</h2><p>Revisamos periódicamente las resoluciones y publicaciones oficiales de cada provincia. Cada precio indica desde cuándo rige y de dónde sale. '
        . 'Si ves algo desactualizado, escribinos desde ' . enlace('/contacto/', 'contacto') . '.</p><p>El sitio se financia con publicidad.</p>';
    return ['title' => 'Quiénes somos | MiRTO', 'h1' => 'Quiénes somos', 'desc' => 'MiRTO es una guía independiente sobre la VTV, RTO e ITV en Argentina: precios, vencimientos y plantas de todas las provincias.', 'cuerpo' => $c];
}

function legal_fuentes($D)
{
    $f = [];
    foreach ($D['provincias'] as $p) {
        $src = $p['fuente_precio'] ?? ($p['fuentes'][0] ?? null);
        $f[] = [enlace(provincia_path($p), $p['nombre']), e($p['sigla']), $p['vigencia_desde'] ? e(fecha_corta($p['vigencia_desde'])) : '—',
            $src ? '<a href="' . e($src) . '" rel="nofollow noopener" target="_blank">' . e(parse_url($src, PHP_URL_HOST)) . '</a>' : '—'];
    }
    $c = '<p class="intro">De dónde sale cada dato de MiRTO y cuándo se actualizó por última vez.</p>' . tabla(['Provincia', 'Sigla', 'Precios vigentes desde', 'Fuente'], $f)
        . '<h2>Cómo calculamos los vencimientos</h2><p>Usamos el calendario por terminación de patente que publica cada provincia (cuando existe) y las reglas de periodicidad según la antigüedad del vehículo. '
        . 'Es una referencia: la fecha exacta es la que figura en tu oblea y en el certificado.</p>';
    return ['title' => 'Fuentes de los datos | MiRTO', 'h1' => 'Fuentes de los datos', 'desc' => 'De dónde salen los precios, vencimientos y plantas de la VTV, RTO e ITV que publica MiRTO, provincia por provincia.', 'cuerpo' => $c];
}

function legal_privacidad($D)
{
    $c = '<p>En MiRTO no pedimos registro ni guardamos datos personales. Las herramientas (precio, vencimiento, checklist) funcionan en tu navegador: la patente y los datos que cargás no se envían a ningún servidor. '
        . 'Para tu comodidad, tu navegador puede recordar la provincia elegida y el avance del checklist.</p>'
        . '<h2>Cookies y publicidad</h2><p>Este sitio puede mostrar anuncios de Google AdSense. Google y otros proveedores usan cookies para mostrar anuncios basados en tus visitas anteriores a este y otros sitios. '
        . 'Podés desactivar la publicidad personalizada en la <a href="https://adssettings.google.com" rel="nofollow noopener" target="_blank">configuración de anuncios de Google</a>.</p>'
        . '<h2>Estadísticas</h2><p>Podemos usar Google Analytics para conocer de forma agregada qué páginas se visitan.</p>'
        . '<h2>Tus derechos</h2><p>De acuerdo con la Ley 25.326, podés escribirnos a ' . e(cfg('email_contacto')) . '.</p>';
    return ['title' => 'Política de privacidad | MiRTO', 'h1' => 'Política de privacidad', 'desc' => 'Política de privacidad de MiRTO: no guardamos tu patente ni datos personales; cómo usamos las cookies de publicidad.', 'cuerpo' => $c];
}

function legal_terminos($D)
{
    $c = '<p>MiRTO publica información sobre la verificación técnica vehicular con fines exclusivamente informativos. No es un sitio oficial ni reemplaza la información de los organismos de cada provincia.</p>'
        . '<h2>Exactitud de los datos</h2><p>Los precios y requisitos los fija cada provincia y pueden cambiar sin aviso. Hacemos lo posible para mantenerlos al día, pero pueden contener demoras o errores. Confirmá siempre en el sitio oficial antes de ir.</p>'
        . '<h2>Turnos</h2><p>No damos turnos ni cobramos ningún trámite. Si alguien te pide dinero en nombre de MiRTO, es un engaño.</p>'
        . '<h2>Enlaces externos</h2><p>Enlazamos a sitios oficiales y de terceros como referencia; no somos responsables por su contenido.</p>';
    return ['title' => 'Términos de uso | MiRTO', 'h1' => 'Términos de uso', 'desc' => 'Términos de uso de MiRTO: información orientativa sobre la VTV, sitio no oficial, sin gestión de turnos.', 'cuerpo' => $c];
}

function legal_contacto($D)
{
    $m = e(cfg('email_contacto'));
    $c = '<p class="intro">¿Viste un precio desactualizado, una planta que cerró o un dato que no coincide? Escribinos a <a href="mailto:' . $m . '">' . $m . '</a> con el enlace a la fuente oficial y lo corregimos.</p>'
        . '<p>Recordá que <strong>no damos turnos</strong>: para eso entrá al sitio oficial de tu provincia.</p>';
    return ['title' => 'Contacto | MiRTO', 'h1' => 'Contacto', 'desc' => 'Contactá a MiRTO para reportar un precio desactualizado o un dato de la VTV, RTO o ITV que no coincide.', 'cuerpo' => $c];
}
