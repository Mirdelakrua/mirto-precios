<?php
// Guías por tipo de vehículo y situación: motos, camionetas, taxis y remises, cada cuánto, vencida,
// descuentos, polarizado y GNC. Las tablas salen de datos-vtv/provincias.json (más los precios aprobados),
// así que se actualizan solas cuando cambia un precio.

function seccion_guias_extra($D)
{
    if (!$D['ok']['vtv']) return;
    registrar('/vtv-moto/', 0, 'vtv', function () use ($D) { return guia_moto($D); });
    registrar('/vtv-camioneta/', 0, 'vtv', function () use ($D) { return guia_camioneta($D); });
    registrar('/vtv-taxi-y-remis/', 0, 'vtv', function () use ($D) { return guia_taxi($D); });
    registrar('/cada-cuanto-se-hace-la-vtv/', 0, 'vtv', function () use ($D) { return guia_frecuencia($D); });
    registrar('/vtv-vencida/', 0, 'vtv', function () use ($D) { return guia_vencida($D); });
    registrar('/descuentos-vtv/', 0, 'vtv', function () use ($D) { return guia_descuentos($D); });
    registrar('/vtv-vidrios-polarizados/', 0, 'vtv', function () use ($D) { return guia_polarizado($D); });
    registrar('/vtv-gnc/', 0, 'vtv', function () use ($D) { return guia_gnc($D); });
}

// ---------- Auxiliares ----------

function gx_fuentes($l)
{
    $ls = [];
    foreach ($l as $f) $ls[] = '<a href="' . e($f[1]) . '" rel="nofollow noopener" target="_blank">' . e($f[0]) . '</a>';
    return '<p class="nota">Fuentes: ' . implode(' · ', $ls) . '.</p>';
}

// Frases de las notas de precio de una provincia que hablan de un tema (motos, camionetas, taxis)
function gx_frases($p, $re)
{
    $out = [];
    foreach (preg_split('/(?<=\.)\s+/u', (string) ($p['notas_precio'] ?? '')) as $f) if (preg_match($re, $f)) $out[] = trim($f);
    return implode(' ', $out);
}

function gx_link_prov($p)
{
    return enlace(provincia_path($p), $p['nombre']);
}

// Tabla de precios de una categoría en las provincias que la publican, de mayor a menor
function gx_tabla_cat($D, $cat, $titulo, $con_auto = false, $re_nota = null)
{
    $f = [];
    $orden = [];
    foreach ($D['provincias'] as $p) {
        $v = vtv_precio($p, $cat);
        if ($v === null) continue;
        $orden[] = [$v, $p];
    }
    usort($orden, function ($a, $b) { return $b[0] <=> $a[0]; });
    foreach ($orden as $o) {
        $p = $o[1];
        $fila = [gx_link_prov($p) . ' <span class="tenue">(' . e($p['sigla']) . ')</span>', pesos($o[0])];
        if ($con_auto) $fila[] = pesos_vtv(vtv_precio($p));
        if ($re_nota) $fila[] = e(gx_frases($p, $re_nota));
        $fila[] = !empty($p['vigencia_desde']) ? e(mes_anio($p['vigencia_desde'])) : '—';
        $f[] = $fila;
    }
    $enc = ['Provincia', 'Precio'];
    if ($con_auto) $enc[] = 'Auto';
    if ($re_nota) $enc[] = 'Detalle';
    $enc[] = 'Desde';
    return [count($f), $f ? tabla($enc, $f, $con_auto ? [1, 2] : [1], null, $titulo) : ''];
}

function gx_contar_periodicidad($D, $re)
{
    $n = [];
    foreach ($D['provincias'] as $p) if (!empty($p['periodicidad']) && preg_match($re, $p['periodicidad'])) $n[] = $p;
    return $n;
}

// ---------- Motos ----------

function guia_moto($D)
{
    $ba = $D['provincias']['buenos-aires'] ?? null;
    $caba = $D['provincias']['caba'] ?? null;
    list($n, $tabla) = gx_tabla_cat($D, 'moto', 'Precio de la VTV de una moto por provincia (cilindrada más baja)', true, '/^Motos?/u');
    $c = '<p class="intro">Las motos también tienen que hacer la verificación técnica en casi todo el país, y en varias provincias más seguido que los autos: '
        . 'en <strong>Provincia de Buenos Aires</strong> la primera VTV de una moto es <strong>al año del patentamiento</strong> y después todos los años, mientras que un auto recién la hace a los dos años. '
        . 'El precio suele ser entre un tercio y la mitad de lo que paga un auto, y en algunas provincias sube con la cilindrada. Abajo tenés el precio en ' . $n . ' provincias, cada cuánto se hace, qué llevar y qué revisan en una moto.</p>';
    if ($ba && $caba) $c .= datos_clave([['Moto en Buenos Aires', pesos_vtv(vtv_precio($ba, 'moto')), 'hasta 200 cc'], ['Moto en CABA', pesos_vtv(vtv_precio($caba, 'moto')), 'plantas oficiales'], ['Primera VTV (PBA)', 'Al año', 'del patentamiento'], ['Renovación (PBA)', 'Anual', 'por terminación de patente']]);
    $c .= anuncio('arriba');
    $c .= '<h2>¿Cuánto cuesta la VTV de una moto?</h2>' . $tabla
        . '<p>En las provincias que no aparecen, el sitio oficial no publica una tarifa separada para motos o cada taller fija la suya: consultala en la planta. '
        . 'Para comparar con lo que paga un auto en todo el país, mirá el ' . enlace('/precio-vtv/', 'precio de la VTV en cada provincia') . '.</p>';
    $c .= '<h2>¿Cada cuánto se hace la VTV de una moto?</h2>';
    $f = [];
    foreach ($D['provincias'] as $p) {
        if (empty($p['periodicidad']) || !preg_match('/motos?/iu', $p['periodicidad'])) continue;
        $f[] = [gx_link_prov($p), e($p['periodicidad'])];
    }
    if ($f) $c .= tabla(['Provincia', 'Régimen'], $f, [], null, 'Provincias que publican una regla para motos');
    $c .= '<p>En el resto rige la regla general de cada provincia, que en la práctica suele ser la misma que para los autos. '
        . 'La norma nacional (Decreto 779/95, artículo 34, texto según el Decreto 196/2025) fija para los particulares una vigencia de 24 meses mientras el vehículo tiene hasta 10 años y de 12 meses después, pero cada jurisdicción aplica su propio sistema y varias no adhirieron. '
        . 'Calculá tu fecha en ' . enlace('/cuando-vence-la-vtv/', '¿cuándo vence mi VTV?') . '.</p>';
    $c .= anuncio('medio');
    $c .= '<h2>Qué llevar</h2><ul><li><strong>DNI</strong> de quien la lleva y <strong>licencia de conducir</strong> vigente para moto.</li>'
        . '<li><strong>Cédula del vehículo.</strong> En CABA, si la presenta otra persona, la cédula verde y/o rosa; en Provincia de Buenos Aires puede ir cualquier persona con la documentación de la moto y su DNI.</li>'
        . '<li>En CABA también piden el seguro vigente y la constancia de pago del turno. Más detalle en ' . enlace('/documentacion-para-la-vtv/', 'qué documentación llevar') . '.</li></ul>';
    $c .= '<h2>Qué revisan en una moto</h2><p>El control es más corto que el de un auto, pero se rechazan muchas motos por detalles fáciles de arreglar antes del turno:</p><ul>'
        . '<li><strong>Luces:</strong> faro con alta y baja, luz de posición, stop (con freno delantero y trasero), giros y luz de patente.</li>'
        . '<li><strong>Frenos:</strong> eficacia de ambos frenos en el banco de pruebas.</li>'
        . '<li><strong>Neumáticos:</strong> dibujo suficiente y sin cortes ni deformaciones.</li>'
        . '<li><strong>Dirección y suspensión:</strong> sin juego en la horquilla ni pérdidas en los amortiguadores.</li>'
        . '<li><strong>Escape:</strong> silenciador completo y sin ruido excesivo; los escapes libres o modificados son una causa frecuente de observación.</li>'
        . '<li><strong>Espejos, bocina y patente</strong> visible y bien sujeta.</li></ul>'
        . '<p>A diferencia de un auto, a una moto no se le pide matafuego ni balizas. La lista completa de controles está en ' . enlace('/que-revisan-en-la-vtv/', 'qué revisan en la VTV') . '.</p>';
    $c .= '<h2>Si la moto no aprueba</h2><p>Con resultado condicional o rechazado tenés que reparar lo observado y volver a la misma planta. En Provincia de Buenos Aires el plazo es de 60 días sin volver a pagar; en CABA, 60 días hábiles. '
        . 'Con rechazo no podés circular hasta aprobar. Más detalle en ' . enlace('/resultado-de-la-vtv/', 'apto, condicional o rechazado') . '.</p>';
    $c .= gx_fuentes([['VTV Provincia de Buenos Aires – Preguntas frecuentes', 'https://vtv.gba.gob.ar/preguntasfrecuentes'], ['VTV Provincia de Buenos Aires – Costos', 'https://vtv.gba.gob.ar/costos'],
        ['Gobierno de la Ciudad – Verificación Técnica Vehicular Obligatoria', 'https://buenosaires.gob.ar/tramites/verificacion-tecnica-vehicular-obligatoria'],
        ['Decreto 779/95, Anexo 1, texto actualizado (InfoLEG)', 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/30000-34999/30389/texactdto779-1995-anexo1.htm']]);
    $c .= enlaces_relacionados([['/precio-vtv/', 'Precio de la VTV en cada provincia'], ['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/que-revisan-en-la-vtv/', 'Qué revisan en la VTV'], ['/turno-vtv/', 'Cómo sacar turno']]);
    $faqs = [];
    if ($ba) $faqs[] = ['¿Cuánto cuesta la VTV de una moto en Provincia de Buenos Aires?', pesos_vtv(vtv_precio($ba, 'moto')) . ' hasta 200 cc. ' . e(gx_frases($ba, '/^Motos?/u'))];
    $faqs[] = ['¿Cada cuánto se hace la VTV de una moto en Buenos Aires?', 'La primera, al año del patentamiento; después, todos los años en el mes que corresponde a la terminación de la patente.'];
    $faqs[] = ['¿Las motos necesitan matafuego para la VTV?', 'No. El matafuego y las balizas se exigen a los autos; en una moto se revisan luces, frenos, neumáticos, dirección, escape, espejos y patente.'];
    return ['title' => 'VTV de motos: precio por provincia y cada cuánto se hace', 'h1' => 'VTV para motos: precio, frecuencia y qué revisan',
        'desc' => 'Cuánto cuesta la VTV o RTO de una moto en cada provincia, cada cuánto hay que hacerla, qué documentación llevar y qué controlan en la revisión.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'sitios oficiales de cada provincia'];
}

// ---------- Camionetas ----------

function guia_camioneta($D)
{
    list($n, $tabla) = gx_tabla_cat($D, 'camioneta', 'Precio de la VTV de una camioneta o pick-up por provincia', true, '/(Camioneta|Pick-?up|furgón|3\.500)/iu');
    $ba = $D['provincias']['buenos-aires'] ?? null;
    $c = '<p class="intro">Una camioneta, pick-up o utilitario liviano de uso particular hace la verificación técnica igual que un auto, pero en muchas provincias paga una <strong>tarifa más alta</strong> y en algunas la hace más seguido. '
        . 'La línea que separa las categorías suele ser el peso: hasta 2.500 kg (en algunas provincias hasta 3.500 kg) es un liviano; arriba de eso pasa a la tarifa de vehículos pesados o de carga. '
        . 'Abajo tenés la comparación con el precio de un auto en ' . $n . ' provincias.</p>';
    $c .= anuncio('arriba');
    $c .= '<h2>¿Cuánto cuesta la VTV de una camioneta?</h2>' . $tabla;
    if ($ba) $c .= '<p><strong>En Provincia de Buenos Aires</strong> las camionetas de hasta 2.500 kg pagan la tarifa básica, la misma que un auto (' . pesos_vtv(vtv_precio($ba)) . '); los vehículos de más de 2.500 kg y de carga pagan ' . pesos_vtv(vtv_precio($ba, 'pesado')) . '.</p>';
    $c .= '<p>En las provincias que no figuran, el sitio oficial no distingue camionetas o el precio lo fija cada taller. Si tu pick-up está inscripta como vehículo de carga o la usás para trabajar, confirmá la categoría al sacar el turno: cambia el precio y a veces la frecuencia.</p>';
    $c .= '<h2>¿Cada cuánto se hace?</h2><p>Para una camioneta particular rige, en general, la misma regla que para un auto de esa provincia. Hay excepciones: en la <strong>ciudad de Córdoba</strong>, por ejemplo, las camionetas y utilitarios hacen la primera ITV al año del 0 km, mientras que los autos la hacen a los dos años. '
        . 'Los vehículos que no son de uso particular (carga, transporte de pasajeros) tienen, según la norma nacional, una vigencia máxima de 12 meses. Revisá la regla de tu provincia en ' . enlace('/cada-cuanto-se-hace-la-vtv/', 'cada cuánto se hace la VTV') . '.</p>';
    $c .= anuncio('medio');
    $c .= '<h2>Qué tener en cuenta en una pick-up</h2><ul>'
        . '<li><strong>Accesorios:</strong> barras antivuelco, defensas, enganches y faros auxiliares no pueden tapar luces ni la patente. Los faros extra encendidos o mal alineados son motivo de observación.</li>'
        . '<li><strong>Neumáticos:</strong> si cambiaste la medida original por cubiertas más grandes, que no rocen ni sobresalgan de la carrocería.</li>'
        . '<li><strong>Carga:</strong> llevala vacía. La caja con carga suelta complica la revisión de luces traseras y patente.</li>'
        . '<li><strong>Elementos obligatorios:</strong> matafuego vigente, balizas y, en CABA, botiquín dentro del habitáculo.</li></ul>'
        . '<p>Antes de ir, repasá el ' . enlace('/que-revisan-en-la-vtv/', 'checklist de lo que revisan') . '.</p>';
    $c .= gx_fuentes([['VTV Provincia de Buenos Aires – Costos', 'https://vtv.gba.gob.ar/costos'], ['Gobierno de la Ciudad – VTV Obligatoria', 'https://buenosaires.gob.ar/tramites/verificacion-tecnica-vehicular-obligatoria'],
        ['Decreto 779/95, Anexo 1, texto actualizado (InfoLEG)', 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/30000-34999/30389/texactdto779-1995-anexo1.htm']]);
    $c .= enlaces_relacionados([['/precio-vtv/', 'Precio de la VTV en cada provincia'], ['/vtv-moto/', 'VTV de motos'], ['/vtv-taxi-y-remis/', 'VTV de taxis y remises'], ['/que-revisan-en-la-vtv/', 'Qué revisan en la VTV']]);
    $faqs = [];
    if ($ba) $faqs[] = ['¿Cuánto paga una camioneta la VTV en Provincia de Buenos Aires?', 'Si pesa hasta 2.500 kg, la tarifa básica de ' . pesos_vtv(vtv_precio($ba)) . ', igual que un auto. Con más de 2.500 kg o de carga, ' . pesos_vtv(vtv_precio($ba, 'pesado')) . '.'];
    $faqs[] = ['¿Una pick-up hace la VTV con la misma frecuencia que un auto?', 'Si es de uso particular, en general sí. Hay excepciones como la ciudad de Córdoba, donde camionetas y utilitarios hacen la primera ITV al año del 0 km.'];
    return ['title' => 'VTV de camionetas y pick-ups: precio por provincia', 'h1' => 'VTV para camionetas, pick-ups y utilitarios',
        'desc' => 'Cuánto cuesta la VTV o RTO de una camioneta o pick-up en cada provincia comparado con un auto, cada cuánto se hace y qué revisan en los accesorios.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'sitios oficiales de cada provincia'];
}

// ---------- Taxis y remises ----------

function guia_taxi($D)
{
    list($n, $tabla) = gx_tabla_cat($D, 'taxi', 'Precio de la VTV de un taxi o remís por provincia', true);
    $seis = gx_contar_periodicidad($D, '/(Taxi|Remis|pasajeros).{0,40}6 meses/iu');
    $c = '<p class="intro">Los taxis, remises y vehículos de transporte de pasajeros hacen una verificación técnica más exigente que un auto particular: la norma nacional les fija una <strong>vigencia máxima de 12 meses</strong> sin excepción, y '
        . count($seis) . ' provincias les piden la revisión <strong>cada 6 meses</strong>. A cambio, en Provincia de Buenos Aires tienen un 50% de descuento. Abajo tenés el precio en ' . $n . ' provincias y la frecuencia en cada una.</p>';
    $c .= anuncio('arriba');
    $c .= '<h2>¿Cuánto cuesta la VTV de un taxi o remís?</h2>' . $tabla
        . '<p>En Provincia de Buenos Aires no hay una tarifa aparte: taxis, remises y transporte escolar pagan la tarifa del vehículo con un <strong>50% de descuento</strong>, que hay que pedir antes de sacar el turno. '
        . 'En CABA, las consultas sobre la verificación de taxis se hacen a taxis@buenosaires.gob.ar.</p>';
    $c .= '<h2>¿Cada cuánto la tienen que hacer?</h2>';
    if ($seis) {
        $f = [];
        foreach ($seis as $p) $f[] = [gx_link_prov($p), e($p['periodicidad'])];
        $c .= tabla(['Provincia', 'Régimen publicado'], $f, [], null, 'Provincias con revisión cada 6 meses para taxis, remises o transporte de pasajeros');
    }
    $c .= '<p>El Decreto 779/95 (artículo 34, inciso 6, texto según el Decreto 196/2025) dice que las provincias pueden estirar los plazos para los autos particulares, pero no para los vehículos que no son de uso particular: para ellos la vigencia no puede pasar de 12 meses. '
        . 'Además, el municipio que otorga la licencia de taxi o remís puede pedir controles propios.</p>';
    $c .= anuncio('medio');
    $c .= '<h2>Cómo pedir el 50% de descuento en Provincia de Buenos Aires</h2><ol>'
        . '<li>Entrá al portal oficial de VTV con tu usuario y elegí el vehículo.</li>'
        . '<li>Cargá la documentación que acredita que es taxi, remís o transporte escolar.</li>'
        . '<li>Esperá la aprobación: la solicitud figura como pendiente, aprobada o rechazada.</li>'
        . '<li>Sacá el turno. Si el beneficio no está aprobado el día de la verificación, se paga la tarifa completa.</li></ol>'
        . '<p>El beneficio vale para un solo vehículo por año y no se suma a otros descuentos. Todos los beneficios están en ' . enlace('/descuentos-vtv/', 'descuentos y exenciones de la VTV') . '.</p>';
    $c .= '<h2>Qué se revisa además</h2><p>Además de los controles de cualquier auto (' . enlace('/que-revisan-en-la-vtv/', 'luces, frenos, dirección, suspensión, gases') . '), en un vehículo de servicio se mira con más atención el estado de los asientos, los cinturones de todas las plazas, las puertas y cerraduras, y los elementos de seguridad obligatorios. '
        . 'Si el vehículo tiene GNC, la oblea del equipo tiene que estar vigente: mirá ' . enlace('/vtv-gnc/', 'VTV con GNC') . '.</p>';
    $c .= gx_fuentes([['VTV Provincia de Buenos Aires – Preguntas frecuentes (beneficios)', 'https://vtv.gba.gob.ar/preguntasfrecuentes'], ['Gobierno de la Ciudad – VTV Obligatoria', 'https://buenosaires.gob.ar/tramites/verificacion-tecnica-vehicular-obligatoria'],
        ['Decreto 779/95, Anexo 1, texto actualizado (InfoLEG)', 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/30000-34999/30389/texactdto779-1995-anexo1.htm']]);
    $c .= enlaces_relacionados([['/descuentos-vtv/', 'Descuentos y exenciones'], ['/vtv-camioneta/', 'VTV de camionetas'], ['/cada-cuanto-se-hace-la-vtv/', 'Cada cuánto se hace la VTV'], ['/precio-vtv/', 'Precio de la VTV']]);
    $faqs = [['¿Cada cuánto hace la VTV un taxi?', 'Como máximo cada 12 meses según la norma nacional. En provincias como ' . implode(', ', array_map(function ($p) { return $p['nombre']; }, array_slice($seis, 0, 4))) . ' se exige cada 6 meses.'],
        ['¿Los remises tienen descuento en la VTV de Provincia de Buenos Aires?', 'Sí: taxis, remises y transporte escolar tienen un 50% de descuento, que se pide en el portal oficial antes de sacar el turno.']];
    return ['title' => 'VTV de taxis y remises: precio y frecuencia por provincia', 'h1' => 'VTV para taxis y remises',
        'desc' => 'Cuánto cuesta y cada cuánto hacen la VTV o RTO los taxis, remises y el transporte de pasajeros en cada provincia, y cómo pedir el 50% de descuento en Buenos Aires.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'sitios oficiales de cada provincia y Decreto 779/95'];
}

// ---------- Cada cuánto ----------

function guia_frecuencia($D)
{
    $f = [];
    $sin = [];
    foreach ($D['provincias'] as $p) {
        if (empty($p['periodicidad'])) { $sin[] = $p; continue; }
        $f[] = [gx_link_prov($p) . ' <span class="tenue">(' . e($p['sigla']) . ')</span>', e($p['periodicidad'])];
    }
    $nac = gx_contar_periodicidad($D, '/esquema nacional|5 años/iu');
    $c = '<p class="intro">No hay una única respuesta: cada provincia decide cuándo hace la primera verificación un 0 km y cada cuánto se renueva. '
        . 'En <strong>Provincia de Buenos Aires</strong> los autos la hacen a los 2 años del patentamiento y después <strong>todos los años</strong>; en <strong>CABA</strong> y <strong>Mendoza</strong> ya rige un esquema parecido al nacional, con la primera a los 5 años y renovaciones cada 2 años hasta los 10 años de antigüedad. '
        . 'Abajo tenés la regla publicada en ' . count($f) . ' jurisdicciones.</p>';
    $c .= datos_clave([['Norma nacional', '24 meses', 'hasta 10 años de antigüedad'], ['Después de los 10 años', '12 meses', 'según la norma nacional'], ['0 km (nacional)', '5 años', 'de gracia'], ['Uso no particular', 'Máx. 12 meses', 'taxis, carga, pasajeros']]);
    $c .= anuncio('arriba');
    $c .= '<h2>Qué dice la norma nacional</h2><p>El Decreto 779/95 (artículo 34, texto según el Decreto 196/2025) establece que:</p><ul>'
        . '<li>Los autos particulares 0 km tienen <strong>60 meses de gracia</strong> desde el patentamiento para la primera revisión.</li>'
        . '<li>Después, la revisión vale <strong>24 meses</strong> mientras el vehículo tiene hasta 10 años, y <strong>12 meses</strong> cuando es más viejo.</li>'
        . '<li>Las provincias pueden fijar plazos mayores para los particulares, pero nunca para los vehículos que no son de uso particular, que tienen un máximo de 12 meses.</li></ul>'
        . '<p>Cada provincia aplica su propio sistema y no todas adhirieron: Buenos Aires, por ejemplo, mantuvo la VTV anual. Por eso la tabla de abajo es la que manda en la práctica.</p>';
    $c .= '<h2>Cada cuánto se hace en cada provincia</h2>' . tabla(['Provincia', 'Regla para particulares'], $f, [], null, 'Primera revisión y renovación de la VTV, RTO o ITV');
    if ($sin) $c .= '<p>No encontramos la regla publicada para ' . implode(', ', array_map('gx_link_prov', $sin)) . '. En esos casos consultá en la planta o en el organismo de tránsito provincial.</p>';
    $c .= anuncio('medio');
    $c .= '<h2>El mes de vencimiento depende de la patente</h2><p>En Buenos Aires, CABA y otras jurisdicciones el vencimiento no es un año después de la fecha en que la hiciste, sino el <strong>mes asignado al último número de la patente</strong>. En Provincia: 2 febrero, 3 marzo, 4 abril, 5 mayo, 6 junio, 7 julio, 8 agosto, 9 septiembre, 0 octubre y 1 noviembre. '
        . 'Podés hacerla hasta 30 días antes, pero eso no corre el vencimiento. Calculá tu fecha exacta en ' . enlace('/cuando-vence-la-vtv/', '¿cuándo vence mi VTV?') . '.</p>';
    $c .= '<h2>Motos, camionetas y taxis</h2><p>Las reglas cambian según el vehículo: en Buenos Aires las motos la hacen desde el primer año, en Córdoba las camionetas también, y los taxis y remises tienen como máximo 12 meses (6 en varias provincias). Mirá ' . enlace('/vtv-moto/', 'VTV de motos') . ', ' . enlace('/vtv-camioneta/', 'camionetas') . ' y ' . enlace('/vtv-taxi-y-remis/', 'taxis y remises') . '.</p>';
    $c .= gx_fuentes([['Decreto 779/95, Anexo 1, texto actualizado (InfoLEG)', 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/30000-34999/30389/texactdto779-1995-anexo1.htm'], ['VTV Provincia de Buenos Aires – Preguntas frecuentes', 'https://vtv.gba.gob.ar/preguntasfrecuentes'],
        ['Gobierno de la Ciudad – VTV Obligatoria', 'https://buenosaires.gob.ar/tramites/verificacion-tecnica-vehicular-obligatoria']]);
    $c .= enlaces_relacionados([['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/vtv-auto-0km/', 'VTV de un auto 0 km'], ['/vtv-vencida/', 'Si se te venció la VTV'], ['/provincias/', 'VTV en cada provincia']]);
    $faqs = [['¿La VTV es anual o cada dos años?', 'Depende de la provincia. En Buenos Aires es anual desde los 2 años del 0 km. En CABA y Mendoza es cada 2 años hasta los 10 años de antigüedad y después anual.'],
        ['¿Qué dice la ley nacional sobre la frecuencia de la VTV?', '60 meses de gracia para un 0 km particular, después 24 meses hasta los 10 años de antigüedad y 12 meses para los más viejos. Cada provincia puede tener su propio régimen.']];
    return ['title' => '¿Cada cuánto se hace la VTV? Regla de cada provincia', 'h1' => '¿Cada cuánto se hace la VTV en cada provincia?',
        'desc' => 'Cada cuánto hay que hacer la VTV, RTO o ITV en cada provincia: cuándo es la primera de un 0 km, si es anual o cada 2 años y qué dice la norma nacional.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'Decreto 779/95 y sitios oficiales de cada provincia'];
}

// ---------- VTV vencida ----------

function guia_vencida($D)
{
    $c = '<p class="intro">Si se te venció la VTV, <strong>la podés hacer igual</strong>: en Provincia de Buenos Aires no hay recargo por hacerla tarde y en CABA podés sacar turno para el mes siguiente. Lo que no podés es <strong>circular</strong> con ella vencida: si te paran, te pueden multar y, según la jurisdicción, retener el vehículo o emplazarte a hacerla. '
        . 'Tampoco ganás tiempo por hacerla tarde: el próximo vencimiento sigue siendo el mes que te toca por la patente.</p>';
    $c .= anuncio('arriba');
    $c .= '<h2>¿Se puede hacer la VTV vencida?</h2><ul>'
        . '<li><strong>Provincia de Buenos Aires:</strong> sí, sin recargo. Una vez hecha, el vencimiento se ajusta al mes que corresponde al último número de la patente.</li>'
        . '<li><strong>CABA:</strong> sí; quien no la hizo antes del vencimiento puede pedir turno para el mes siguiente. La Ciudad aclara que eso no evita las sanciones si circulaste con la VTV vencida, y que la oblea mantiene la vigencia que habría tenido si la hacías en término.</li>'
        . '<li><strong>Otras provincias:</strong> en general se puede hacer en cualquier momento; lo que cambia es la multa por circular sin ella. Revisá la página de tu provincia en ' . enlace('/provincias/', 'VTV en cada provincia') . '.</li></ul>';
    $c .= '<h2>¿Cuánto tiempo se puede circular con la VTV vencida?</h2><p><strong>Ninguno.</strong> No hay un plazo de tolerancia: desde el primer día después del vencimiento, circular sin la revisión al día es una falta. '
        . 'La norma nacional (Decreto 779/95, artículo 34) dice que los vehículos que no puedan acreditar la revisión serán emplazados a hacerla y <strong>no podrán salir de la jurisdicción</strong> donde están radicados hasta cumplirla, además de la multa que corresponda.</p>'
        . '<p>Lo que sí existe es el margen para hacerla <strong>antes</strong>: en Buenos Aires podés verificar hasta 30 días antes del mes que te toca sin perder vigencia.</p>';
    $c .= anuncio('medio');
    $c .= '<h2>¿Y si no uso el auto?</h2><p>La VTV es obligatoria para <strong>circular</strong>. La Provincia de Buenos Aires lo dice expresamente: si el vehículo no se usa, no es necesario hacerla. Cuando lo vuelvas a sacar a la calle, tenés que verificarlo antes.</p>';
    $c .= '<h2>Qué conviene hacer</h2><ol><li>Fijate cuándo vencía con el ' . enlace('/cuando-vence-la-vtv/', 'calculador de vencimiento') . '.</li>'
        . '<li>Sacá turno lo antes posible en el sitio oficial (' . enlace('/turno-vtv/', 'cómo sacar turno') . '). Si el turno es en varios días, evitá usar el auto mientras tanto.</li>'
        . '<li>Revisá luces, neumáticos y elementos obligatorios para no tener que volver: ' . enlace('/que-revisan-en-la-vtv/', 'checklist de lo que revisan') . '.</li>'
        . '<li>Si ya te multaron, mirá ' . enlace('/multa-por-no-tener-vtv/', 'cuánto es la multa en cada provincia') . '.</li></ol>';
    $c .= gx_fuentes([['VTV Provincia de Buenos Aires – Preguntas frecuentes', 'https://vtv.gba.gob.ar/preguntasfrecuentes'], ['Gobierno de la Ciudad – VTV Obligatoria (VTV después de su vencimiento)', 'https://buenosaires.gob.ar/tramites/verificacion-tecnica-vehicular-obligatoria'],
        ['Decreto 779/95, Anexo 1, texto actualizado (InfoLEG)', 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/30000-34999/30389/texactdto779-1995-anexo1.htm']]);
    $c .= enlaces_relacionados([['/multa-por-no-tener-vtv/', 'Multa por no tener la VTV'], ['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/turno-vtv/', 'Cómo sacar turno'], ['/cada-cuanto-se-hace-la-vtv/', 'Cada cuánto se hace']]);
    $faqs = [['¿Hay recargo por hacer la VTV vencida?', 'En Provincia de Buenos Aires no: se paga la misma tarifa. El problema es circular con ella vencida, que puede terminar en multa.'],
        ['¿Cuántos días se puede circular con la VTV vencida?', 'Ninguno. No hay tolerancia: desde el día siguiente al vencimiento circular sin la revisión al día es una falta.'],
        ['Si hago la VTV tarde, ¿me dura un año desde que la hice?', 'No. En Buenos Aires y CABA el vencimiento sigue atado al mes que corresponde a la terminación de la patente.']];
    return ['title' => 'VTV vencida: ¿se puede hacer y circular? Qué pasa', 'h1' => 'Se me venció la VTV: qué pasa y qué hacer',
        'desc' => 'Si se te venció la VTV: si la podés hacer igual, si hay recargo, cuánto tiempo se puede circular, qué dice la norma nacional y qué pasa si no usás el auto.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => FUENTE_NAC];
}

// ---------- Descuentos ----------

function guia_descuentos($D)
{
    $f = [];
    foreach ($D['provincias'] as $p) if (!empty($p['descuentos'])) $f[] = [gx_link_prov($p), e($p['descuentos'])];
    $c = '<p class="intro">Hay descuentos y exenciones en la VTV, pero <strong>no son automáticos</strong>: casi siempre hay que pedirlos y tenerlos aprobados antes del turno. '
        . 'En Provincia de Buenos Aires, las personas con Certificado Único de Discapacidad no pagan, y los jubilados que cumplen los requisitos, los autos de 20 años o más y los taxis y remises pagan la mitad. '
        . 'En CABA no pagan los jubilados y mayores de 65 de bajos ingresos ni los titulares con discapacidad. Abajo tenés el detalle y lo que publica cada provincia.</p>';
    $c .= anuncio('arriba');
    $c .= '<h2>Provincia de Buenos Aires</h2>' . tabla(['Beneficio', 'Quiénes'], [
            ['<strong>Exención total</strong>', 'Personas con discapacidad (Certificado Único de Discapacidad).'],
            ['<strong>50% de descuento</strong>', 'Jubilados y pensionados que cumplan los requisitos.'],
            ['<strong>50% de descuento</strong>', 'Vehículos de 20 años o más.'],
            ['<strong>50% de descuento</strong>', 'Taxis, remises y transporte escolar.']], [], null, 'Beneficios de la VTV bonaerense')
        . '<p>Reglas que conviene saber: el beneficio vale para <strong>un solo vehículo por año</strong> y <strong>no se acumula</strong> con otro. Se pide en el portal oficial de VTV antes de sacar el turno, cargando la documentación; queda en evaluación y aparece como pendiente, aprobado o rechazado. '
        . 'Podés sacar turno mientras está en evaluación, pero si el día de la verificación no está aprobado, pagás la tarifa completa sin excepción.</p>';
    $c .= '<h2>Ciudad de Buenos Aires</h2><p>Están exentos de pagar:</p><ul><li>Jubilados, pensionados y mayores de 65 años titulares de un vehículo que cobren hasta 2 haberes mínimos jubilatorios.</li>'
        . '<li>Personas con discapacidad titulares del vehículo.</li><li>Personas con discapacidad que no son titulares, cuando el auto es de sus padres, tutores, hijos, cónyuge o conviviente (con al menos 2 años de convivencia).</li></ul>'
        . '<p>Se pide en la web del Gobierno de la Ciudad, adjuntando cédula, título, DNI y, según el caso, comprobante de haberes o Certificado Único de Discapacidad, más el kilometraje y el CUIT/CUIL del titular. También se puede mandar la documentación escaneada a exentosvtv@buenosaires.gob.ar. '
        . 'La exención es del pago: el vehículo igual tiene que hacer la verificación.</p>';
    $c .= anuncio('medio');
    if ($f) $c .= '<h2>Qué publica cada provincia</h2>' . tabla(['Provincia', 'Descuentos y exenciones'], $f, [], null, 'Beneficios publicados en los sitios oficiales')
        . '<p>Si tu provincia no aparece, no encontramos beneficios publicados en su sitio oficial; preguntá en la planta, porque algunos talleres hacen descuentos propios. En las provincias con precios libres o máximos, como Mendoza, cada taller puede cobrar menos que el tope.</p>';
    $c .= '<h2>Otras formas de pagar menos</h2><ul><li><strong>No pierdas la reverificación gratis:</strong> si salís condicional o rechazado, volvé a la misma planta dentro del plazo (60 días en Buenos Aires). Pasado ese plazo, se paga todo de nuevo.</li>'
        . '<li><strong>Llevá el auto revisado:</strong> una lámpara quemada o un matafuego vencido te hacen volver. Usá el ' . enlace('/que-revisan-en-la-vtv/', 'checklist') . '.</li>'
        . '<li><strong>Compará plantas</strong> donde el precio es libre: en el ' . enlace('/precio-vtv/', 'precio de la VTV por provincia') . ' indicamos cuándo es un tope.</li></ul>';
    $c .= gx_fuentes([['VTV Provincia de Buenos Aires – Preguntas frecuentes (beneficios)', 'https://vtv.gba.gob.ar/preguntasfrecuentes'], ['Gobierno de la Ciudad – VTV Obligatoria (exención de pago)', 'https://buenosaires.gob.ar/tramites/verificacion-tecnica-vehicular-obligatoria']]);
    $c .= enlaces_relacionados([['/precio-vtv/', 'Precio de la VTV en cada provincia'], ['/vtv-taxi-y-remis/', 'VTV de taxis y remises'], ['/documentacion-para-la-vtv/', 'Qué llevar a la VTV'], ['/turno-vtv/', 'Cómo sacar turno']]);
    $faqs = [['¿Los jubilados pagan la VTV en Provincia de Buenos Aires?', 'Tienen un 50% de descuento si cumplen los requisitos. Hay que pedirlo en el portal oficial y tenerlo aprobado antes del turno.'],
        ['¿Las personas con discapacidad pagan la VTV?', 'En Provincia de Buenos Aires y en CABA están exentas del pago, para un solo vehículo. Igual tienen que hacer la verificación.'],
        ['¿Los autos viejos tienen descuento en la VTV?', 'En Provincia de Buenos Aires, los vehículos de 20 años o más tienen un 50% de descuento.']];
    return ['title' => 'Descuentos en la VTV: quién no paga y quién paga la mitad', 'h1' => 'Descuentos y exenciones de la VTV',
        'desc' => 'Quiénes no pagan la VTV y quiénes tienen 50% de descuento en Buenos Aires, CABA y otras provincias: jubilados, discapacidad, autos de 20 años y taxis. Cómo pedirlo.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => 'sitios oficiales de PBA, CABA y cada provincia'];
}

// ---------- Polarizado ----------

function guia_polarizado($D)
{
    $c = '<p class="intro">Los vidrios polarizados no están permitidos por la normativa de tránsito, pero en la VTV <strong>no todos tienen el mismo efecto</strong>. En Provincia de Buenos Aires, el sitio oficial aclara que no son motivo de rechazo, <strong>salvo en el parabrisas</strong>, donde el vehículo puede ser observado. '
        . 'La regla técnica de fondo es la transparencia: los vidrios tienen que dejar pasar al menos el <strong>75% de la luz en el parabrisas</strong> y el <strong>70% en el resto</strong>.</p>';
    $c .= datos_clave([['Parabrisas', '75%', 'transmitancia mínima'], ['Resto de los vidrios', '70%', 'transmitancia mínima'], ['En la VTV de PBA', 'Observado', 'sólo si es el parabrisas']]);
    $c .= anuncio('arriba');
    $c .= '<h2>Qué dice la norma</h2><p>La Ley Nacional de Tránsito 24.449 (artículo 30, inciso f) exige que los autos tengan vidrios de seguridad "normalizados y con el grado de tonalidad adecuados". '
        . 'Su reglamentación, el Decreto 779/95, fija la transmitancia luminosa mínima: 75% en el parabrisas y 70% en los demás vidrios. Además, los vidrios no pueden deformar lo que se ve a través de ellos ni confundir los colores de la señalización. '
        . 'La mayoría de las láminas polarizadas que se venden dejan pasar bastante menos luz, por eso en la práctica casi cualquier polarizado agregado queda fuera de la norma.</p>'
        . '<p>Los vidrios tonalizados de fábrica (los que vienen levemente verdes o grises) cumplen la norma porque están homologados.</p>';
    $c .= '<h2>Qué pasa en la VTV</h2><ul>'
        . '<li><strong>Parabrisas polarizado o con lámina oscura:</strong> es el caso que la VTV bonaerense marca. Incluye las franjas oscuras que bajan más allá del borde superior y tapan el campo de visión.</li>'
        . '<li><strong>Laterales y luneta:</strong> en Provincia de Buenos Aires no son motivo de rechazo en la VTV, aunque siguen estando fuera de la norma y te pueden multar en un control.</li>'
        . '<li><strong>Otras provincias:</strong> el criterio depende de cada concesionaria. Hubo casos en Córdoba en que la ITV emplazaba a quitar las láminas oscuras para aprobar. Ante la duda, consultá en la planta antes del turno.</li></ul>';
    $c .= anuncio('medio');
    $c .= '<h2>Multas fuera de la VTV</h2><p>Aunque la VTV no te rechace por los laterales, en la calle la situación es otra: varias jurisdicciones multan los vidrios polarizados fuera de norma. Si te piden sacar la lámina, se quita en cualquier casa de polarizados; despegarla bien (sin dejar pegamento) es importante para no terminar con el vidrio manchado, que también puede ser observado.</p>';
    $c .= '<h2>Antes de ir</h2><ul><li>Si tu parabrisas tiene lámina, sacala antes del turno para no tener que volver.</li><li>Revisá que el parabrisas no tenga roturas en el campo de visión del conductor: es otra causa común de observación.</li>'
        . '<li>Repasá el resto del ' . enlace('/que-revisan-en-la-vtv/', 'checklist de la VTV') . '.</li></ul>';
    $c .= gx_fuentes([['VTV Provincia de Buenos Aires – Preguntas frecuentes', 'https://vtv.gba.gob.ar/preguntasfrecuentes'], ['Ley 24.449 de Tránsito, texto actualizado (InfoLEG)', 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/0-4999/818/texact.htm'],
        ['La Voz de San Justo – "Con polarizados, no hay ITV" (transmitancia según el Decreto 779/95)', 'https://www.lavozdesanjusto.com.ar/con-polarizados-no-hay-itv-49952']]);
    $c .= enlaces_relacionados([['/que-revisan-en-la-vtv/', 'Qué revisan en la VTV'], ['/resultado-de-la-vtv/', 'Apto, condicional o rechazado'], ['/perdi-la-oblea-de-la-vtv/', 'Si se rompió el parabrisas con la oblea'], ['/multa-por-no-tener-vtv/', 'Multas']]);
    $faqs = [['¿Rechazan la VTV por tener los vidrios polarizados?', 'En Provincia de Buenos Aires no, salvo que el polarizado esté en el parabrisas: en ese caso el vehículo puede ser observado.'],
        ['¿Qué porcentaje de polarizado está permitido?', 'La reglamentación exige que el parabrisas deje pasar al menos el 75% de la luz y el resto de los vidrios el 70%. La mayoría de las láminas oscuras no cumplen.'],
        ['¿Los vidrios tonalizados de fábrica están permitidos?', 'Sí, porque están homologados y cumplen la transmitancia mínima.']];
    return ['title' => 'Vidrios polarizados y VTV: ¿te rechazan? Qué dice la ley', 'h1' => 'Vidrios polarizados en la VTV',
        'desc' => 'Si los vidrios polarizados hacen que te rechacen la VTV: qué dice la Ley 24.449, cuánta luz tienen que dejar pasar los vidrios y qué pasa en Buenos Aires con el parabrisas.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => FUENTE_NAC];
}

// ---------- GNC ----------

function guia_gnc($D)
{
    $c = '<p class="intro">Un auto con GNC hace la misma VTV que uno a nafta, pero además tiene que tener <strong>al día la documentación del equipo de gas</strong>: la <strong>oblea de habilitación</strong> y la <strong>cédula de identificación del equipo</strong>, que se renuevan en un taller de montaje habilitado por ENARGAS. '
        . 'Si la oblea de GNC está vencida, el auto puede quedar observado aunque todo lo demás esté bien. Abajo te explicamos qué piden, qué controles tiene el equipo y en qué orden conviene hacer los trámites.</p>';
    $c .= datos_clave([['Oblea de GNC', 'Anual', 'taller de montaje habilitado'], ['Cilindros', 'Cada 5 años', 'revisión en un CRPC'], ['En la VTV', 'Oblea vigente', 'y cédula del equipo']]);
    $c .= anuncio('arriba');
    $c .= '<h2>Qué te piden en la VTV</h2><ul><li><strong>Oblea de GNC vigente</strong> pegada en el parabrisas.</li><li><strong>Cédula de identificación del equipo</strong>.</li><li>El resto de la documentación de siempre: DNI, cédula del vehículo y licencia. Ver ' . enlace('/documentacion-para-la-vtv/', 'qué llevar') . '.</li></ul>'
        . '<p>La norma nacional (Decreto 779/95) remite, para la seguridad de los vehículos a GNC o GNL, a las normas del Ente Nacional Regulador del Gas (ENARGAS). Por eso la planta de VTV no revisa el equipo por dentro: controla que tenga la habilitación vigente que otorga un taller de montaje. En CABA, presentar esa documentación es una exigencia formal para verificar un auto con GNC.</p>';
    $c .= '<h2>Los controles propios del equipo de gas</h2><h3>Revisión anual (oblea)</h3><p>Una vez por año hay que llevar el auto a un <strong>taller de montaje habilitado</strong> por ENARGAS, que revisa la instalación completa —conexiones, cañerías, válvulas y regulador— y renueva la oblea. Sin oblea vigente tampoco te cargan gas en las estaciones de servicio.</p>'
        . '<h3>Revisión de cilindros cada 5 años</h3><p>Cada cinco años los cilindros se desmontan y van a un <strong>Centro de Revisión Periódica de Cilindros (CRPC)</strong>, donde se les hace la prueba hidráulica y otras mediciones para certificar que siguen siendo seguros. Si el cilindro no aprueba, hay que reemplazarlo. Esa revisión suele coincidir con la renovación de la oblea de ese año.</p>';
    $c .= anuncio('medio');
    $c .= '<h2>En qué orden conviene hacerlo</h2><ol><li>Fijate la fecha de vencimiento en la oblea de GNC y en la cédula del equipo.</li>'
        . '<li>Si vence antes de tu turno de VTV, o en el mismo mes, <strong>renová primero la oblea de GNC</strong>.</li>'
        . '<li>Después sacá turno para la VTV (' . enlace('/turno-vtv/', 'cómo sacarlo') . ') y llevá la cédula del equipo.</li></ol>'
        . '<p>Los autos con GNC suelen observarse también por cosas que no son del gas: luces, neumáticos y emisiones. Repasá el ' . enlace('/que-revisan-en-la-vtv/', 'checklist de lo que revisan') . ' antes de ir.</p>';
    $c .= gx_fuentes([['Decreto 779/95, Anexo 1, texto actualizado (InfoLEG)', 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/30000-34999/30389/texactdto779-1995-anexo1.htm'], ['iProfesional – VTV y GNC: qué controles adicionales se realizan', 'https://www.iprofesional.com/autos/451185-vtv-y-gnc-que-controles-adicionales-se-realizan'],
        ['Gobierno de la Ciudad – VTV Obligatoria', 'https://buenosaires.gob.ar/tramites/verificacion-tecnica-vehicular-obligatoria']]);
    $c .= enlaces_relacionados([['/que-revisan-en-la-vtv/', 'Qué revisan en la VTV'], ['/documentacion-para-la-vtv/', 'Qué llevar'], ['/vtv-taxi-y-remis/', 'VTV de taxis y remises'], ['/resultado-de-la-vtv/', 'Apto, condicional o rechazado']]);
    $faqs = [['¿Puedo hacer la VTV con la oblea de GNC vencida?', 'Podés presentarte, pero el auto puede quedar observado y no obtener la aprobación plena. Conviene renovar primero la oblea en un taller de montaje habilitado.'],
        ['¿Cada cuánto se revisa el equipo de GNC?', 'La instalación completa, una vez por año para renovar la oblea; los cilindros, cada 5 años con prueba hidráulica en un Centro de Revisión Periódica de Cilindros.'],
        ['¿La planta de VTV revisa el equipo de gas?', 'No por dentro: controla que tenga la oblea y la cédula del equipo vigentes. La revisión técnica del gas la hace un taller habilitado por ENARGAS.']];
    return ['title' => 'VTV con GNC: qué piden y cómo pasarla', 'h1' => 'VTV de un auto con GNC',
        'desc' => 'Qué piden en la VTV a un auto con GNC: oblea y cédula del equipo vigentes, revisión anual en taller de montaje y prueba de cilindros cada 5 años.',
        'cuerpo' => $c, 'faqs' => $faqs, 'fuente' => FUENTE_NAC . ' y normas de ENARGAS'];
}
