<?php
// Guías: qué revisan (checklist), documentación, resultados, multas, 0 km, otra provincia y oblea.

const FUENTE_NAC = 'Ley 24.449, Decreto 779/95 (texto según Decreto 196/2025) y sitios oficiales de PBA y CABA';

function seccion_guias($D)
{
    if (!$D['ok']['vtv']) return;
    registrar('/que-revisan-en-la-vtv/', 0, 'vtv', function () use ($D) { return guia_revisan($D); });
    registrar('/documentacion-para-la-vtv/', 0, 'vtv', function () use ($D) { return guia_documentacion($D); });
    registrar('/multa-por-no-tener-vtv/', 0, 'vtv', function () use ($D) { return guia_multas($D); });
    registrar('/resultado-de-la-vtv/', 0, 'vtv', function () use ($D) { return guia_resultados($D); });
    registrar('/vtv-auto-0km/', 0, 'vtv', function () use ($D) { return guia_0km($D); });
    registrar('/vtv-en-otra-provincia/', 0, 'vtv', function () use ($D) { return guia_otra_provincia($D); });
    registrar('/perdi-la-oblea-de-la-vtv/', 0, 'vtv', function () use ($D) { return guia_oblea($D); });
    if (guia_texto('/turno-vtv/')) registrar('/turno-vtv/', 0, 'vtv', function () use ($D) { return guia_desde_texto('/turno-vtv/', '', [['/plantas/', 'Plantas de VTV, RTO e ITV'], ['/documentacion-para-la-vtv/', 'Qué llevar a la VTV'], ['/precio-vtv/', 'Precio de la VTV']]); });
}

// Textos largos de las guías (investigados y con fuentes), en datos-vtv/guias.json
function guia_texto($path)
{
    static $g = null;
    if ($g === null) $g = leer_json(dirname(__DIR__) . '/datos-vtv/guias.json', []);
    return $g[$path] ?? null;
}

// Arma la guía con el texto largo; $antes = herramienta interactiva que va arriba
function guia_desde_texto($path, $antes, $rel, $extra = [])
{
    $t = guia_texto($path);
    $c = $antes . anuncio('arriba') . $t['cuerpo'];
    if (!empty($t['fuentes'])) {
        $c .= '<p class="nota">Fuentes: ';
        $ls = [];
        foreach ($t['fuentes'] as $f) $ls[] = '<a href="' . e($f['url']) . '" rel="nofollow noopener" target="_blank">' . e($f['nombre']) . '</a>';
        $c .= implode(' · ', $ls) . '.</p>';
    }
    $c .= anuncio('medio') . enlaces_relacionados($rel);
    return array_merge(['title' => $t['title'], 'h1' => $t['h1'], 'desc' => $t['desc'], 'cuerpo' => $c, 'faqs' => $t['faqs'] ?? [], 'fuente' => FUENTE_NAC], $extra);
}

function checklist_items()
{
    return [
        'Luces' => ['luces-bajas' => 'Luces bajas y altas encienden y están alineadas', 'giros' => 'Giros delanteros y traseros funcionan (y titilan)', 'stop' => 'Luces de freno, incluido el tercer stop', 'posicion' => 'Luces de posición y de patente', 'retroceso' => 'Luz de retroceso y balizas'],
        'Frenos y dirección' => ['freno' => 'El auto frena parejo, sin tirar hacia un lado', 'freno-mano' => 'El freno de mano sostiene el auto', 'direccion' => 'La dirección no tiene juego ni ruidos'],
        'Neumáticos y suspensión' => ['dibujo' => 'Neumáticos con dibujo suficiente (más de 1,6 mm) y sin cortes', 'auxilio' => 'Rueda de auxilio en condiciones', 'amortiguadores' => 'Amortiguadores sin pérdidas de aceite'],
        'Seguridad' => ['cinturones' => 'Cinturones de seguridad en todos los asientos', 'matafuego' => 'Matafuego cargado y vigente (no se exige en motos)', 'balizas' => 'Balizas triangulares', 'bocina' => 'Bocina funcionando', 'espejos' => 'Espejos retrovisores sanos'],
        'Vidrios y carrocería' => ['parabrisas' => 'Parabrisas sin roturas en el campo de visión', 'polarizado' => 'Parabrisas sin polarizar', 'limpia' => 'Limpiaparabrisas funcionando', 'patentes' => 'Patentes legibles y bien sujetas'],
        'Motor y escape' => ['humo' => 'El escape no larga humo excesivo', 'ruido' => 'Silenciador sin pérdidas ni ruido fuerte', 'perdidas' => 'Sin pérdidas de aceite o combustible'],
    ];
}

function guia_revisan($D)
{
    if (guia_texto('/que-revisan-en-la-vtv/')) {
        $chk = '<section class="calculadora" id="checklist"><h2>Checklist: ¿pasa mi auto?</h2>';
        foreach (checklist_items() as $grupo => $items) {
            $chk .= '<fieldset class="check-grupo"><legend>' . e($grupo) . '</legend>';
            foreach ($items as $k => $t) $chk .= '<label class="check"><input type="checkbox" name="' . e($k) . '"> ' . e($t) . '</label>';
            $chk .= '</fieldset>';
        }
        $chk .= '<div class="resultado" aria-live="polite"></div><button type="button" class="reiniciar">Empezar de nuevo</button><p class="nota">Tu progreso queda guardado sólo en este navegador.</p></section>';
        return guia_desde_texto('/que-revisan-en-la-vtv/', $chk, [['/documentacion-para-la-vtv/', 'Qué documentación llevar'], ['/resultado-de-la-vtv/', 'Apto, condicional o rechazado'], ['/precio-vtv/', 'Precio de la VTV'], ['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?']], ['js' => true]);
    }

    $c = '<p class="intro">En la VTV revisan que tu vehículo sea seguro y no contamine: luces, frenos, dirección, suspensión, neumáticos, chasis, emisiones y elementos de seguridad. '
        . 'Marcá lo que ya revisaste y te decimos qué te falta antes de ir. Las luces son la causa de rechazo más común.</p>';
    $c .= '<section class="calculadora" id="checklist"><h2>Checklist: ¿pasa mi auto?</h2>';
    foreach (checklist_items() as $grupo => $items) {
        $c .= '<fieldset class="check-grupo"><legend>' . e($grupo) . '</legend>';
        foreach ($items as $k => $t) $c .= '<label class="check"><input type="checkbox" name="' . e($k) . '"> ' . e($t) . '</label>';
        $c .= '</fieldset>';
    }
    $c .= '<div class="resultado" aria-live="polite"></div><button type="button" class="reiniciar">Empezar de nuevo</button>'
        . '<p class="nota">Tu progreso queda guardado sólo en este navegador.</p></section>';
    $c .= anuncio('arriba');
    $c .= '<h2>Qué controlan en la VTV (lista oficial de Buenos Aires)</h2><ol><li>Luces reglamentarias</li><li>Sistema de frenos</li><li>Identificación del vehículo</li><li>Dirección y tren delantero</li><li>Suspensión</li><li>Chasis</li><li>Neumáticos</li><li>Llantas</li><li>Contaminación ambiental (gases y ruido)</li><li>Estado general</li><li>Elementos de seguridad y emergencia</li></ol>'
        . '<p>En CABA la lista es equivalente e incluye la emisión de gases y de ruidos y la documentación del vehículo. El taller usa equipos como alineador de faros, frenómetro, detector de holguras, analizador de gases y opacímetro.</p>';
    $c .= '<h2>Las fallas más comunes</h2><ul><li><strong>Luces:</strong> la lámpara de la patente o del tercer stop quemada, faros desalineados o giros que no titilan bien. Es el motivo de rechazo más frecuente por amplio margen.</li>'
        . '<li><strong>Suspensión y dirección:</strong> bujes, extremos o rótulas con juego y amortiguadores con pérdidas.</li><li><strong>Frenos:</strong> diferencia de frenado entre la rueda izquierda y la derecha.</li></ul>'
        . '<p>Un dato: en la Provincia de Buenos Aires el polarizado sólo es causa de rechazo en el parabrisas.</p>';
    $c .= anuncio('medio');
    $c .= enlaces_relacionados([['/documentacion-para-la-vtv/', 'Qué documentación llevar'], ['/resultado-de-la-vtv/', 'Apto, condicional o rechazado'], ['/precio-vtv/', 'Precio de la VTV'], ['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?']]);
    return ['title' => '¿Qué revisan en la VTV? Checklist para no rebotar', 'h1' => 'Qué revisan en la VTV',
        'desc' => 'Qué controlan en la VTV, RTO o ITV: luces, frenos, dirección, neumáticos, gases y seguridad. Checklist interactivo para revisar tu auto antes de ir.',
        'cuerpo' => $c, 'js' => true, 'fuente' => FUENTE_NAC,
        'faqs' => [['¿Cuál es la causa más común de rechazo en la VTV?', 'Las luces: lámparas quemadas (patente, tercer stop), faros desalineados o giros que no funcionan bien.'],
            ['¿Te rechazan la VTV por el polarizado?', 'En la Provincia de Buenos Aires sólo es causa de rechazo el polarizado del parabrisas.']]];
}

function guia_documentacion($D)
{
    if (guia_texto('/documentacion-para-la-vtv/')) return guia_desde_texto('/documentacion-para-la-vtv/', '', [['/que-revisan-en-la-vtv/', 'Qué revisan en la VTV'], ['/turno-vtv/', 'Cómo sacar turno'], ['/precio-vtv/', 'Precio de la VTV'], ['/plantas/', 'Plantas de VTV']]);

    $c = '<p class="intro">Para hacer la VTV necesitás básicamente tu <strong>DNI</strong> y la <strong>cédula del vehículo</strong>. Según la provincia te pueden pedir algo más; acá va el detalle.</p>';
    $c .= '<h2>Provincia de Buenos Aires</h2><ul><li>Documento de identidad de quien lleva el vehículo (no hace falta que sea el titular).</li><li>Cédula verde (o azul).</li>'
        . '<li>Título de propiedad, sólo en la primera verificación.</li><li>CUIT, si corresponde.</li><li>Licencia de conducir vigente (la piden las preguntas frecuentes oficiales).</li></ul>'
        . '<p>El DNI y la cédula digitales de la app Mi Argentina son válidos.</p>';
    $c .= anuncio('arriba');
    $c .= '<h2>Ciudad de Buenos Aires</h2><p>El turno y el pago se hacen online. Llevá la cédula verde o azul y tu DNI, además de la documentación que se exige para circular: licencia vigente y seguro vigente (puede ser digital).</p>';
    $c .= '<h2>Resto del país</h2><p>En general: DNI, cédula del vehículo y, en muchos talleres, comprobante del seguro. En los vehículos de uso comercial (taxis, remises, transporte escolar o de carga) suelen pedir la habilitación correspondiente. Confirmalo con la planta al sacar turno.</p>';
    $c .= '<h2>Consejos</h2><ul><li>Llegá unos minutos antes del turno.</li><li>Llevá el comprobante de pago si lo hiciste online.</li><li>Revisá antes las luces y los neumáticos con nuestro ' . enlace('/que-revisan-en-la-vtv/', 'checklist') . '.</li></ul>';
    $c .= anuncio('medio');
    $c .= enlaces_relacionados([['/que-revisan-en-la-vtv/', 'Qué revisan en la VTV'], ['/precio-vtv/', 'Precio de la VTV'], ['/plantas/', 'Plantas de VTV']]);
    return ['title' => 'Qué documentación llevar a la VTV (requisitos)', 'h1' => 'Documentación para la VTV',
        'desc' => 'Qué papeles llevar a la VTV, RTO o ITV: DNI, cédula verde, título y lo que pide cada provincia. Requisitos de Buenos Aires, CABA y el resto del país.',
        'cuerpo' => $c, 'fuente' => 'sitios oficiales de VTV de PBA y CABA',
        'faqs' => [['¿Tiene que ir el titular a hacer la VTV?', 'No. En la Provincia de Buenos Aires puede llevarlo cualquier persona con su DNI y la cédula del vehículo.'],
            ['¿Sirve la cédula digital para la VTV?', 'Sí. El DNI y la cédula digitales de Mi Argentina son válidos en Buenos Aires.']]];
}

function guia_multas($D)
{
    if (guia_texto('/multa-por-no-tener-vtv/')) return guia_desde_texto('/multa-por-no-tener-vtv/', '', [['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/precio-vtv/', 'Precio de la VTV'], ['/turno-vtv/', 'Cómo sacar turno'], ['/plantas/', 'Plantas de VTV']]);

    $f = [];
    foreach ($D['provincias'] as $p) if (!empty($p['multa'])) $f[] = [enlace(provincia_path($p), $p['nombre']), e($p['multa'])];
    $c = '<p class="intro">Circular con la VTV vencida o sin haberla hecho es una falta grave. Además de la multa, te pueden retener la licencia o el vehículo, y no podés salir de tu provincia sin la revisión al día.</p>';
    $c .= datos_clave([['Buenos Aires', '300 a 1.000 UF', 'y retención de licencia'], ['CABA', '400 UF', 'VTV vencida o nunca hecha'], ['Mendoza', '$50.000', 'falta leve (2026)']]);
    $c .= anuncio('arriba');
    $c .= '<h2>Multa por no tener la VTV en cada provincia</h2>' . ($f ? tabla(['Provincia', 'Multa'], $f) : '') . '<p class="nota">En las provincias que no figuran no encontramos el monto publicado.</p>';
    $c .= '<h2>¿Qué es la UF?</h2><p>Las multas de tránsito se fijan en Unidades Fijas (UF). Cada UF equivale al precio de un litro de nafta, por eso el monto en pesos sube cuando aumenta el combustible. Cada jurisdicción publica el valor vigente.</p>';
    $c .= '<h2>¿Me pueden sacar el auto?</h2><p>La Ley Nacional de Tránsito permite retener un vehículo que no cumpla las exigencias de seguridad. En Buenos Aires, además, te retienen la licencia y te dan una boleta de citación: para recuperarla tenés que acreditar que hiciste la VTV.</p>';
    $c .= anuncio('medio');
    $c .= enlaces_relacionados([['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/precio-vtv/', 'Precio de la VTV'], ['/plantas/', 'Plantas de VTV']]);
    return ['title' => 'Multa por no tener la VTV: cuánto es en cada provincia', 'h1' => 'Multa por no tener la VTV',
        'desc' => 'Cuánto es la multa por circular sin VTV, RTO o ITV en Buenos Aires, CABA y otras provincias, y si te pueden retener el auto o la licencia.',
        'cuerpo' => $c, 'fuente' => FUENTE_NAC . ' y normas provinciales',
        'faqs' => [['¿Cuánto es la multa por no tener la VTV en Provincia?', 'De 300 a 1.000 Unidades Fijas, además de la retención de la licencia hasta acreditar la VTV.'],
            ['¿Cuánto es la multa por no tener la VTV en CABA?', 'Según el sitio oficial, 400 UF si la VTV está vencida o nunca se hizo, y 100 UF por no llevar el certificado u oblea.']]];
}

function guia_resultados($D)
{
    if (guia_texto('/resultado-de-la-vtv/')) return guia_desde_texto('/resultado-de-la-vtv/', '', [['/que-revisan-en-la-vtv/', 'Qué revisan en la VTV'], ['/multa-por-no-tener-vtv/', 'Multas'], ['/provincias/', 'VTV en cada provincia']]);

    $c = '<p class="intro">Al terminar la verificación el resultado puede ser <strong>apto</strong>, <strong>condicional</strong> o <strong>rechazado</strong>. Esto significa cada uno y qué tenés que hacer.</p>';
    $c .= '<div class="resultados"><div class="res-caja ok"><strong>Apto</strong><p>No hay fallas, o las que hay no afectan la seguridad. Te dan la oblea y el certificado.</p></div>'
        . '<div class="res-caja alerta"><strong>Condicional</strong><p>Hay fallas que tenés que reparar. Podés circular, pero tenés que volver dentro del plazo (60 días para vehículos particulares) y sólo revisan lo observado.</p></div>'
        . '<div class="res-caja mal"><strong>Rechazado</strong><p>El vehículo no puede circular hasta repararlo y volver a hacer la revisión completa.</p></div></div>';
    $c .= anuncio('arriba');
    $c .= '<h2>¿Tengo que volver a pagar?</h2><ul><li><strong>Buenos Aires:</strong> si volvés a la misma planta dentro de los 60 días, no pagás de nuevo. Pasado ese plazo, pagás la tarifa completa.</li>'
        . '<li><strong>CABA:</strong> tenés 60 días hábiles para reverificar gratis en la misma planta. Si lo reparás el mismo día, podés reverificar sin turno.</li>'
        . '<li><strong>Otras provincias:</strong> en general hay un plazo de 30 a 60 días sin cargo; consultá en la página de tu provincia.</li></ul>';
    $c .= '<h2>Vehículos de uso comercial</h2><p>Para taxis, remises, transporte escolar y de carga, el plazo del condicional es de 30 días y no pueden prestar servicio mientras tanto.</p>';
    $c .= enlaces_relacionados([['/que-revisan-en-la-vtv/', 'Qué revisan en la VTV'], ['/multa-por-no-tener-vtv/', 'Multas'], ['/provincias/', 'VTV en cada provincia']]);
    return ['title' => 'VTV apto, condicional o rechazado: qué significa', 'h1' => 'Resultado de la VTV: apto, condicional o rechazado',
        'desc' => 'Qué significa que la VTV dé apto, condicional o rechazado, cuántos días tenés para volver y si tenés que pagar de nuevo la reverificación.',
        'cuerpo' => $c, 'fuente' => FUENTE_NAC,
        'faqs' => [['¿Puedo circular con la VTV condicional?', 'Sí, dentro del plazo para reverificar (60 días para particulares). Con el resultado rechazado no podés circular.']]];
}

function guia_0km($D)
{
    if (guia_texto('/vtv-auto-0km/')) return guia_desde_texto('/vtv-auto-0km/', herr_form_vence($D), [['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/precio-vtv/', 'Precio de la VTV'], ['/provincias/', 'VTV en cada provincia']], ['js' => true]);

    $f = [];
    foreach ($D['provincias'] as $p) if (!empty($p['nuevo_anios'])) $f[] = [enlace(provincia_path($p), $p['nombre']), $p['nuevo_anios'] . ' años', e($p['periodicidad'] ?? '')];
    $c = '<p class="intro">Un auto 0 km no hace la VTV enseguida: tiene un período de gracia que depende de la provincia. En Buenos Aires son <strong>2 años</strong> desde el patentamiento; en CABA y otras provincias que adoptaron el esquema nacional, <strong>5 años</strong>.</p>';
    $c .= herr_form_vence($D);
    $c .= anuncio('arriba');
    $c .= '<h2>Primera VTV de un 0 km en cada provincia</h2>' . tabla(['Provincia', 'Primera VTV', 'Después'], $f);
    $c .= '<h2>El esquema nacional</h2><p>El Decreto 779/95, modificado en 2025, fija para los vehículos particulares un plazo de gracia de 60 meses desde el patentamiento, y después una vigencia de 24 meses hasta los 10 años de antigüedad y de 12 meses en adelante. '
        . 'Pero cada provincia decide si adhiere: Buenos Aires, por ejemplo, mantiene la VTV anual desde los 2 años.</p>';
    $c .= enlaces_relacionados([['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/precio-vtv/', 'Precio de la VTV'], ['/provincias/', 'VTV en cada provincia']]);
    return ['title' => '¿Cuándo hace la VTV un auto 0 km? Plazos por provincia', 'h1' => 'VTV de un auto 0 km: cuándo es la primera',
        'desc' => 'Cuándo tiene que hacer la primera VTV un auto 0 km en cada provincia: 2 años en Buenos Aires, 5 en CABA y Mendoza, y el resto del país.',
        'cuerpo' => $c, 'js' => true, 'fuente' => FUENTE_NAC,
        'faqs' => [['¿Cuándo hace la primera VTV un 0 km en Provincia de Buenos Aires?', 'A los 2 años del patentamiento; las motos al año. Después, todos los años.']]];
}

function guia_otra_provincia($D)
{
    if (guia_texto('/vtv-en-otra-provincia/')) return guia_desde_texto('/vtv-en-otra-provincia/', '', [['/provincias/', 'VTV en cada provincia'], ['/multa-por-no-tener-vtv/', 'Multas por no tener la VTV'], ['/turno-vtv/', 'Cómo sacar turno']]);

    $c = '<p class="intro">¿Podés hacer la VTV en una provincia distinta de donde está radicado el auto? La norma nacional dice que sí, pero en la práctica depende de tu provincia.</p>';
    $c .= '<h2>Qué dice la norma nacional</h2><p>Desde 2025, el Decreto 779/95 permite hacer la revisión en cualquier taller habilitado "independientemente del lugar de radicación". También establece que un vehículo sin la revisión al día no puede salir de su jurisdicción.</p>';
    $c .= anuncio('arriba');
    $c .= '<h2>Qué pasa en la práctica</h2><ul><li><strong>Buenos Aires:</strong> los vehículos de otras provincias pueden hacer la VTV de manera voluntaria, pero no reemplaza la obligación de su jurisdicción. Un auto radicado en la Provincia tiene que cumplir la VTV bonaerense.</li>'
        . '<li><strong>CABA:</strong> la VTV porteña está destinada a vehículos radicados en la Ciudad.</li><li><strong>Santa Fe:</strong> no acepta revisiones de otras jurisdicciones, salvo transporte interjurisdiccional.</li>'
        . '<li><strong>Entre Ríos:</strong> según la información disponible, no exige la RTO a los particulares y Santa Fe y Córdoba no se la piden a los autos entrerrianos en tránsito.</li></ul>'
        . '<p>Antes de viajar, hacé la revisión de tu provincia o confirmá con la autoridad de tránsito del lugar al que vas.</p>';
    $c .= enlaces_relacionados([['/provincias/', 'VTV en cada provincia'], ['/multa-por-no-tener-vtv/', 'Multas por no tener la VTV']]);
    return ['title' => '¿Se puede hacer la VTV en otra provincia?', 'h1' => 'VTV en otra provincia: ¿se puede?',
        'desc' => 'Si podés hacer la VTV o RTO en una provincia distinta de donde está radicado tu auto: qué dice la norma nacional y qué aceptan Buenos Aires, CABA y Santa Fe.',
        'cuerpo' => $c, 'fuente' => FUENTE_NAC];
}

function guia_oblea($D)
{
    if (guia_texto('/perdi-la-oblea-de-la-vtv/')) return guia_desde_texto('/perdi-la-oblea-de-la-vtv/', '', [['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/multa-por-no-tener-vtv/', 'Multas'], ['/turno-vtv/', 'Cómo sacar turno']]);

    $c = '<p class="intro">La oblea de la VTV va pegada en el parabrisas y, junto con el certificado, acredita que hiciste la revisión. Si la perdiste o se rompió el vidrio, se puede reponer.</p>';
    $c .= '<h2>Cómo reponer la oblea</h2><ul><li><strong>Buenos Aires:</strong> presentá en la planta la oblea anterior o el recorte del vidrio con la oblea; si no lo tenés, una denuncia policial.</li>'
        . '<li><strong>CABA:</strong> con la denuncia policial te la reponen gratis en la planta.</li></ul>';
    $c .= anuncio('arriba');
    $c .= '<h2>¿Sirve el certificado digital?</h2><p>Sí. La norma nacional prevé un certificado digital con la misma validez que la oblea física, y se puede mostrar en un control desde el celular.</p>'
        . '<h2>Cuándo vence la oblea</h2><p>En Buenos Aires y CABA el vencimiento queda fijo en el mes que corresponde a la terminación de la patente. Calculalo en ' . enlace('/cuando-vence-la-vtv/', '¿cuándo vence mi VTV?') . '.</p>';
    $c .= enlaces_relacionados([['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?'], ['/multa-por-no-tener-vtv/', 'Multas']]);
    return ['title' => 'Perdí la oblea de la VTV: cómo reponerla', 'h1' => 'Perdí la oblea de la VTV',
        'desc' => 'Qué hacer si perdiste la oblea de la VTV o se rompió el parabrisas: cómo reponerla en Buenos Aires y CABA y si sirve el certificado digital.',
        'cuerpo' => $c, 'fuente' => FUENTE_NAC];
}
