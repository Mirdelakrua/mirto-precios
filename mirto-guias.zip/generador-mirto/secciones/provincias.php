<?php
// Páginas por provincia, por localidad (plantas) e índices.

function seccion_provincias($D)
{
    if (!$D['ok']['vtv']) return;
    registrar('/provincias/', 0, 'vtv', function () use ($D) { return prov_indice($D); });
    registrar('/plantas/', 0, 'vtv', function () use ($D) { return plantas_indice($D); });
    $prio_alta = ['buenos-aires', 'caba', 'cordoba', 'santa-fe', 'mendoza', 'tucuman', 'salta', 'misiones', 'corrientes', 'entre-rios'];
    foreach ($D['provincias'] as $s => $p) {
        registrar(provincia_path($p), 0, 'vtv', function () use ($D, $p) { return prov_pagina($D, $p); });
    }
    foreach (grupos_plantas($D) as $g) {
        if ($g['provincia'] === 'caba') continue;   // CABA ya lista sus plantas en su página
        registrar($g['path'], 0, 'vtv', function () use ($D, $g) { return localidad_pagina($D, $g); });
    }
}

function grupos_plantas($D)
{
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = [];
    $usados = [];
    foreach ($D['provincias'] as $p) $usados[provincia_path($p)] = true;
    foreach ($D['plantas'] as $pl) {
        if (!$pl['grupo'] || !isset($D['provincias'][$pl['provincia']])) continue;
        $k = $pl['provincia'] . '|' . $pl['grupo'];
        if (!isset($cache[$k])) {
            $p = $D['provincias'][$pl['provincia']];
            $path = '/' . strtolower($p['sigla']) . '-' . slug($pl['grupo']) . '/';
            if (isset($usados[$path])) $path = '/' . strtolower($p['sigla']) . '-' . slug($pl['grupo']) . '-ciudad/';
            $usados[$path] = true;
            $cache[$k] = ['provincia' => $pl['provincia'], 'nombre' => $pl['grupo'], 'path' => $path, 'plantas' => []];
        }
        $cache[$k]['plantas'][] = $pl;
    }
    return $cache;
}

function planta_mapa_url($pl)
{
    if ($pl['lat'] && $pl['lng']) return 'https://www.google.com/maps/search/?api=1&query=' . $pl['lat'] . ',' . $pl['lng'];
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(($pl['direccion'] ?? '') . ', ' . ($pl['localidad'] ?: $pl['grupo']));
}

function plantas_lista($plantas)
{
    $h = '<ul class="plantas">';
    foreach ($plantas as $pl) {
        $h .= '<li class="planta"><strong>' . e($pl['nombre']) . '</strong>'
            . ($pl['direccion'] ? '<span>' . e($pl['direccion']) . ($pl['localidad'] && stripos($pl['direccion'], $pl['localidad']) === false ? ', ' . e($pl['localidad']) : '') . '</span>' : '')
            . ($pl['horarios'] ? '<span class="tenue">Horario: ' . e($pl['horarios']) . '</span>' : '')
            . ($pl['telefono'] ? '<span class="tenue">Teléfono: ' . e($pl['telefono']) . '</span>' : '')
            . '<span class="planta-links"><a href="' . e(planta_mapa_url($pl)) . '" rel="nofollow noopener" target="_blank">Cómo llegar</a>'
            . ($pl['web'] ? ' · <a href="' . e($pl['web']) . '" rel="nofollow noopener" target="_blank">Sitio web</a>' : '') . '</span>'
            . ($pl['aviso'] ? '<span class="nota">' . e($pl['aviso']) . '</span>' : '') . '</li>';
    }
    return $h . '</ul>';
}

function precio_viejo($p)
{
    return !empty($p['vigencia_desde']) && $p['vigencia_desde'] < sumar_dias(hoy(), -240);
}

function prov_tabla_precios($p)
{
    $f = [];
    foreach (vtv_categorias() as $cat => $c) {
        if (!array_key_exists($cat, $p['precios'])) continue;
        $f[] = [e($c['largo']), pesos_vtv($p['precios'][$cat]['precio'])];
    }
    return $f ? tabla(['Vehículo', 'Precio'], $f, [1], null, 'Precio de la ' . $p['sigla'] . ' en ' . $p['nombre'] . (!empty($p['vigencia_desde']) ? ' (desde ' . fecha_corta($p['vigencia_desde']) . ')' : '')) : '';
}

function obligatoria_txt($p)
{
    $o = $p['obligatoria'] ?? null;
    if ($o === true) return 'Sí';
    if ($o === false) return 'No para autos particulares';
    if ($o === 'parcial') return 'Depende del municipio';
    return 'Sin confirmar';
}

function prov_pagina($D, $p)
{
    $sig = $p['sigla'];
    $nom = $p['nombre'];
    $auto = vtv_precio($p);
    $plantas = array_values(array_filter($D['plantas'], function ($x) use ($p) { return $x['provincia'] === $p['slug']; }));
    $c = '<p class="intro">';
    if ($auto !== null) $c .= 'La <strong>' . e($sig) . ' en ' . e($nom) . '</strong> cuesta <strong>' . pesos($auto) . '</strong> para un auto particular' . (!empty($p['vigencia_desde']) ? ' (precio vigente desde ' . ($p['fecha_aprox'] ?? false ? e(mes_anio($p['vigencia_desde'])) : e(fecha_corta($p['vigencia_desde']))) . ')' : '') . '. ';
    else $c .= 'En ' . e($nom) . ' la verificación técnica se llama <strong>' . e($sig) . '</strong>. ';
    $c .= 'Acá tenés el precio para cada tipo de vehículo, cuándo vence, ' . ($plantas ? 'dónde están las plantas' : 'dónde hacerla') . ', qué descuentos hay y qué pasa si circulás sin ella.</p>';
    if (!empty($p['aviso'])) $c .= aviso('<strong>Atención:</strong> ' . e($p['aviso']), 'alerta');
    if (precio_viejo($p)) $c .= aviso('El último precio publicado que encontramos es de ' . e(mes_anio($p['vigencia_desde'])) . '. Es probable que haya aumentado: confirmalo en la planta antes de ir.', 'alerta');
    $c .= datos_clave([['Auto particular', pesos_vtv($auto), e($sig)], ['Moto', pesos_vtv(vtv_precio($p, 'moto')), ''],
        ['¿Es obligatoria?', obligatoria_txt($p), ''], ['Plantas en el sitio', $plantas ? (string) count($plantas) : '—', $plantas ? 'con dirección' : 'sin listado oficial']]);
    $c .= anuncio('arriba');
    $c .= '<h2>¿Cuánto cuesta la ' . e($sig) . ' en ' . e($nom) . '?</h2>' . prov_tabla_precios($p);
    if (!empty($p['notas_precio'])) $c .= '<p>' . e($p['notas_precio']) . '</p>';
    if (!empty($p['actualizacion'])) $c .= '<p><strong>Cómo se actualiza el precio:</strong> ' . e($p['actualizacion']) . '</p>';
    if (!$p['precios']) $c .= '<p>No encontramos un precio oficial publicado para ' . e($nom) . '. Cada taller o planta habilitada informa su tarifa: consultala antes de ir.</p>';
    $c .= herr_form_vence($D, $p['slug']);
    $c .= '<h2>¿Cada cuánto hay que hacerla?</h2><p>' . e($p['periodicidad'] ?? 'No encontramos la periodicidad publicada para ' . $nom . '. A nivel nacional, el Decreto 779/95 prevé para los particulares una primera revisión a los 5 años y luego cada 2 años hasta los 10 años de antigüedad, pero cada provincia aplica su propio régimen.') . '</p>';
    $c .= '<p>' . enlace('/vtv-auto-0km/', '¿Cuándo hace la VTV un auto 0 km?') . ' · ' . enlace('/vtv-en-otra-provincia/', '¿Se puede hacer la VTV en otra provincia?') . '</p>';
    if (!empty($p['calendario'])) $c .= '<h3>Calendario por terminación de patente</h3>' . tabla_calendario($p) . '<p class="nota">Diciembre y enero no tienen terminación asignada. Podés hacerla hasta 30 días antes del vencimiento.</p>';
    $c .= anuncio('medio');
    if ($plantas) {
        $c .= '<h2>Plantas de ' . e($sig) . ' en ' . e($nom) . '</h2>';
        if ($p['slug'] === 'caba' || count($plantas) <= 8) $c .= plantas_lista($plantas);
        else {
            $c .= '<ul class="localidades">';
            foreach (grupos_plantas($D) as $g) if ($g['provincia'] === $p['slug']) { $n = count($g['plantas']); $c .= '<li>' . enlace($g['path'], $sig . ' en ' . $g['nombre']) . '<span>' . $n . ($n === 1 ? ' planta' : ' plantas') . '</span></li>'; }
            $c .= '</ul>';
        }
    }
    if (!empty($p['turnos_url'])) $c .= '<h2>Turnos</h2><p>Los turnos se sacan en el sitio oficial o en el de cada planta: <a href="' . e($p['turnos_url']) . '" rel="nofollow noopener" target="_blank">' . e(parse_url($p['turnos_url'], PHP_URL_HOST)) . '</a>. '
        . 'MiRTO no da turnos ni cobra el trámite.</p>';
    if (!empty($p['descuentos'])) $c .= '<h2>Descuentos y exenciones</h2><p>' . e($p['descuentos']) . '</p>';
    if (!empty($p['reverificacion'])) $c .= '<h2>Si no aprobás</h2><p>' . e($p['reverificacion']) . ' Mirá ' . enlace('/resultado-de-la-vtv/', 'qué significa cada resultado') . '.</p>';
    if (!empty($p['multa'])) $c .= '<h2>Multa por no tener la ' . e($sig) . ' en ' . e($nom) . '</h2><p>' . e($p['multa']) . '</p>';
    if (!empty($p['notas'])) $c .= '<h2>Para tener en cuenta</h2><p>' . e($p['notas']) . '</p>';
    $c .= '<h2>Qué llevar y qué revisan</h2><p>Antes de ir, mirá la ' . enlace('/documentacion-para-la-vtv/', 'documentación que te piden') . ' y usá el ' . enlace('/que-revisan-en-la-vtv/', 'checklist de lo que revisan') . ' para no ir a perder el tiempo.</p>';
    if (!empty($p['fuente_precio'])) $c .= '<p class="nota">Fuente del precio: <a href="' . e($p['fuente_precio']) . '" rel="nofollow noopener" target="_blank">' . e(parse_url($p['fuente_precio'], PHP_URL_HOST)) . '</a>' . (!empty($p['resolucion']) ? ' · ' . e($p['resolucion']) : '') . '.</p>';
    $rel = [['/precio-vtv/', 'Precio de la VTV en todas las provincias'], ['/cuando-vence-la-vtv/', '¿Cuándo vence mi VTV?']];
    foreach (vecinas($p['slug']) as $v) if (isset($D['provincias'][$v])) $rel[] = [provincia_path($D['provincias'][$v]), $D['provincias'][$v]['sigla'] . ' en ' . $D['provincias'][$v]['nombre']];
    $c .= enlaces_relacionados($rel);
    $faqs = [];
    if ($auto !== null) $faqs[] = ['¿Cuánto cuesta la ' . $sig . ' en ' . $nom . '?', pesos($auto) . ' para un auto particular' . (!empty($p['vigencia_desde']) ? ', según el último precio publicado (' . mes_anio($p['vigencia_desde']) . ')' : '') . '.'];
    if (!empty($p['periodicidad'])) $faqs[] = ['¿Cada cuánto se hace la ' . $sig . ' en ' . $nom . '?', e($p['periodicidad'])];
    if (!empty($p['multa'])) $faqs[] = ['¿Cuál es la multa por no tener la ' . $sig . ' en ' . $nom . '?', e($p['multa'])];
    $tit = $sig . ' en ' . $nom . ': precio, vencimiento y plantas';
    return ['title' => titulo_corto($tit, $sig . ' ' . ($p['nombre_corto'] ?? $nom) . ': precio y vencimiento'),
        'h1' => $sig . ' en ' . $nom,
        'desc' => 'Cuánto cuesta la ' . $sig . ' en ' . $nom . ' para autos, motos y camionetas, cada cuánto se hace, plantas, turnos, descuentos y multas.',
        'migas' => [['Provincias', '/provincias/']], 'cuerpo' => $c, 'faqs' => $faqs, 'js' => true, 'fuente' => 'organismos y plantas habilitadas de ' . $nom];
}

function vecinas($s)
{
    $v = ['buenos-aires' => ['caba', 'santa-fe', 'cordoba', 'la-pampa', 'entre-rios'], 'caba' => ['buenos-aires'], 'cordoba' => ['santa-fe', 'san-luis', 'la-rioja', 'santiago-del-estero', 'catamarca'],
        'santa-fe' => ['cordoba', 'buenos-aires', 'entre-rios', 'santiago-del-estero', 'chaco'], 'mendoza' => ['san-juan', 'san-luis', 'neuquen', 'la-pampa'], 'tucuman' => ['salta', 'santiago-del-estero', 'catamarca'],
        'entre-rios' => ['santa-fe', 'corrientes', 'buenos-aires'], 'salta' => ['jujuy', 'tucuman', 'catamarca', 'formosa', 'chaco'], 'misiones' => ['corrientes'], 'corrientes' => ['misiones', 'chaco', 'entre-rios'],
        'neuquen' => ['rio-negro', 'mendoza', 'la-pampa'], 'rio-negro' => ['neuquen', 'chubut', 'la-pampa', 'buenos-aires'], 'chubut' => ['rio-negro', 'santa-cruz'], 'santa-cruz' => ['chubut', 'tierra-del-fuego'],
        'tierra-del-fuego' => ['santa-cruz'], 'jujuy' => ['salta'], 'chaco' => ['corrientes', 'formosa', 'santiago-del-estero', 'salta'], 'formosa' => ['chaco', 'salta'],
        'catamarca' => ['tucuman', 'la-rioja', 'santiago-del-estero', 'salta', 'cordoba'], 'la-rioja' => ['catamarca', 'san-juan', 'cordoba', 'san-luis'], 'san-juan' => ['mendoza', 'la-rioja', 'san-luis'],
        'san-luis' => ['mendoza', 'cordoba', 'san-juan', 'la-pampa'], 'la-pampa' => ['buenos-aires', 'cordoba', 'mendoza', 'rio-negro'], 'santiago-del-estero' => ['tucuman', 'cordoba', 'santa-fe', 'chaco', 'catamarca']];
    return $v[$s] ?? [];
}

function localidad_pagina($D, $g)
{
    $p = $D['provincias'][$g['provincia']];
    $sig = $p['sigla'];
    $nom = $g['nombre'];
    $n = count($g['plantas']);
    $auto = vtv_precio($p);
    $moto = vtv_precio($p, 'moto');
    $prim = $g['plantas'][0];
    $en_prov = $p['slug'] === 'caba' ? 'la Ciudad' : $p['nombre'];
    $sabado = false; $con_horario = []; $con_tel = [];
    foreach ($g['plantas'] as $pl) {
        if ($pl['horarios']) { $con_horario[] = $pl; if (preg_match('/s[áa]b/iu', $pl['horarios'])) $sabado = true; }
        if ($pl['telefono']) $con_tel[] = $pl;
    }

    // Introducción con los datos propios de la localidad
    $c = '<p class="intro">Para hacer la <strong>' . e($sig) . ' en ' . e($nom) . '</strong> (' . e($p['nombre']) . ') tenés ' . ($n === 1 ? 'una planta habilitada' : $n . ' plantas habilitadas') . ' en nuestro listado'
        . ($n === 1 && $prim['direccion'] ? ': <strong>' . e($prim['nombre']) . '</strong>, en ' . e($prim['direccion']) : '') . '. '
        . ($auto !== null ? 'Para un auto particular cuesta <strong>' . pesos($auto) . '</strong>' . ($moto !== null ? ' y para una moto ' . pesos($moto) : '') . ', el mismo precio en toda ' . ($p['slug'] === 'caba' ? 'la Ciudad' : 'la provincia') . '. ' : '')
        . 'Abajo tenés dirección, horarios, teléfono, cómo sacar turno, qué llevar y qué pasa si no aprobás.</p>';
    if (!empty($p['aviso'])) $c .= aviso('<strong>Atención:</strong> ' . e($p['aviso']), 'alerta');
    $c .= anuncio('arriba');
    $c .= '<h2>' . ($n === 1 ? 'Dirección y horario de la planta' : 'Las ' . $n . ' plantas de ' . e($sig) . ' en ' . e($nom)) . '</h2>' . plantas_lista($g['plantas']);
    if (!$con_horario) $c .= '<p class="nota">La fuente oficial no publica el horario de ' . ($n === 1 ? 'esta planta' : 'estas plantas') . ': consultalo por teléfono o al sacar el turno.</p>';

    // Paso a paso con los datos de la localidad
    $c .= '<h2>Cómo hacer la ' . e($sig) . ' en ' . e($nom) . ', paso a paso</h2><ol>';
    $c .= '<li><strong>Sacá turno.</strong> ' . (!empty($p['turnos_url']) ? 'Se pide en el <a href="' . e($p['turnos_url']) . '" rel="nofollow noopener" target="_blank">sitio oficial de ' . e($en_prov) . '</a>' . ($con_tel ? ' o llamando a la planta' : '') . '.' : ($con_tel ? 'Llamá a la planta (' . e($con_tel[0]['telefono']) . ') para confirmar si trabaja con turno o por orden de llegada.' : 'Consultá en la planta si trabaja con turno o por orden de llegada.')) . ' ' . enlace('/turno-vtv/', 'Cómo sacar turno en cada provincia') . '.</li>';
    $c .= '<li><strong>Revisá el auto antes.</strong> Las luces son la causa de rechazo más común: probá giros, stop, patente y balizas. Usá el ' . enlace('/que-revisan-en-la-vtv/', 'checklist de lo que revisan') . '.</li>';
    $c .= '<li><strong>Llevá la documentación:</strong> DNI de quien conduce y cédula del vehículo (verde o azul); según el caso, título, seguro y licencia. Detalle en ' . enlace('/documentacion-para-la-vtv/', 'qué llevar a la VTV') . '.</li>';
    $c .= '<li><strong>Andá a la planta' . ($n === 1 && $prim['direccion'] ? ' de ' . e($prim['direccion']) : '') . '</strong>' . ($con_horario ? ' dentro del horario de atención' . ($sabado ? ' (también abre los sábados)' : '') : '') . ' y llegá unos minutos antes del turno.</li>';
    $c .= '<li><strong>Si da condicional,</strong> ' . (!empty($p['reverificacion']) ? e($p['reverificacion']) : 'reparás lo observado y volvés dentro del plazo que te indiquen (en general, 30 a 60 días) para revisar sólo esos puntos.') . ' ' . enlace('/resultado-de-la-vtv/', 'Qué significa cada resultado') . '.</li></ol>';

    // Precio (todas las categorías) y periodicidad, resumidos
    $c .= '<h2>¿Cuánto cuesta la ' . e($sig) . ' en ' . e($nom) . '?</h2>' . prov_tabla_precios($p);
    if (!empty($p['notas_precio'])) $c .= '<p>' . e($p['notas_precio']) . '</p>';
    if (!empty($p['descuentos'])) $c .= '<p><strong>Descuentos:</strong> ' . e($p['descuentos']) . '</p>';
    $c .= anuncio('medio');
    $c .= '<h2>¿Cada cuánto hay que hacerla?</h2><p>' . e($p['periodicidad'] ?? 'Cada provincia fija su propio régimen; confirmalo en la página de ' . $p['nombre'] . '.') . ' Calculá la fecha exacta de tu auto en ' . enlace('/cuando-vence-la-vtv/', '¿cuándo vence mi ' . $sig . '?') . '.</p>';
    if (!empty($p['multa'])) $c .= '<h2>Si circulás sin la ' . e($sig) . '</h2><p>' . e($p['multa']) . ' Más detalle en ' . enlace('/multa-por-no-tener-vtv/', 'multas por no tener la VTV') . '.</p>';

    // Otras plantas cercanas de la misma provincia, con su dirección
    $imp = array_flip(paginas_impulsar());
    $hermanas = array_values(array_filter(grupos_plantas($D), function ($o) use ($g) { return $o['provincia'] === $g['provincia'] && $o['path'] !== $g['path']; }));
    usort($hermanas, function ($a, $b) use ($imp) { return (isset($imp[$b['path']]) <=> isset($imp[$a['path']])) ?: (count($b['plantas']) <=> count($a['plantas'])); });
    if ($hermanas) {
        $c .= '<h2>Otras plantas de ' . e($sig) . ' en ' . e($en_prov) . '</h2><p>Si no conseguís turno en ' . e($nom) . ', estas son otras opciones de la misma ' . ($p['slug'] === 'caba' ? 'ciudad' : 'provincia') . ' (el precio es el mismo):</p><ul class="localidades">';
        foreach (array_slice($hermanas, 0, 8) as $o) {
            $pl0 = $o['plantas'][0];
            $c .= '<li>' . enlace($o['path'], $sig . ' en ' . $o['nombre']) . '<span>' . e($pl0['direccion'] ?: (count($o['plantas']) . ' plantas')) . '</span></li>';
        }
        $c .= '</ul>';
    }
    $c .= '<p>Toda la información de la provincia (calendario, exenciones y normas) está en ' . enlace(provincia_path($p), $sig . ' en ' . $p['nombre']) . '.</p>';
    $rel = [[provincia_path($p), $sig . ' en ' . $p['nombre']], ['/plantas/', 'Todas las plantas de VTV, RTO e ITV'], ['/precio-vtv/', 'Precio de la VTV en cada provincia']];
    $c .= enlaces_relacionados($rel);

    $faqs = [['¿Dónde hago la ' . $sig . ' en ' . $nom . '?', $n === 1 ? 'En ' . e($prim['nombre']) . ($prim['direccion'] ? ', ' . e($prim['direccion']) : '') . '.' : 'Hay ' . $n . ' plantas: ' . e(implode('; ', array_map(function ($x) { return $x['nombre'] . ($x['direccion'] ? ' (' . $x['direccion'] . ')' : ''); }, $g['plantas']))) . '.']];
    if ($auto !== null) $faqs[] = ['¿Cuánto cuesta la ' . $sig . ' en ' . $nom . '?', pesos($auto) . ' para un auto particular' . ($moto !== null ? ' y ' . pesos($moto) . ' para una moto' : '') . ', igual que en todo ' . e($p['slug'] === 'caba' ? 'el distrito' : 'el territorio de ' . $p['nombre']) . '.'];
    if ($con_horario) $faqs[] = ['¿Qué horario tiene la planta de ' . $sig . ' en ' . $nom . '?', e($con_horario[0]['nombre']) . ': ' . e($con_horario[0]['horarios']) . '.'];
    if ($con_tel) $faqs[] = ['¿Cuál es el teléfono de la ' . $sig . ' en ' . $nom . '?', e($con_tel[0]['nombre']) . ': ' . e($con_tel[0]['telefono']) . '.'];
    if (!empty($p['periodicidad'])) $faqs[] = ['¿Cada cuánto se hace la ' . $sig . '?', e($p['periodicidad'])];
    return ['title' => titulo_corto('Plantas de ' . $sig . ' en ' . $nom . ': dirección y horarios', 'Plantas de ' . $sig . ' en ' . $nom),
        'h1' => 'Plantas de ' . $sig . ' en ' . $nom,
        'desc' => 'Dónde hacer la ' . $sig . ' en ' . $nom . ' (' . $p['nombre'] . '): dirección, horario y teléfono de ' . ($n === 1 ? 'la planta' : 'las ' . $n . ' plantas') . ', turnos, precio y qué llevar.',
        'migas' => [['Provincias', '/provincias/'], [$sig . ' en ' . $p['nombre'], provincia_path($p)]], 'cuerpo' => $c, 'faqs' => $faqs];
}

function prov_indice($D)
{
    $P = $D['provincias'];
    $f = [];
    foreach ($P as $p) $f[] = [enlace(provincia_path($p), $p['nombre']), e($p['sigla']), pesos_vtv(vtv_precio($p)), e(obligatoria_txt($p))];
    $c = '<p class="intro">La verificación técnica cambia de nombre, precio y reglas según la provincia: en Buenos Aires y CABA es la <strong>VTV</strong>, en Córdoba la <strong>ITV</strong> y en la mayoría del país la <strong>RTO</strong>. Elegí la tuya:</p>';
    $c .= lista_provincias($P);
    $c .= anuncio('arriba');
    $c .= '<h2>Resumen por provincia</h2>' . tabla(['Provincia', 'Nombre', 'Auto', '¿Obligatoria?'], $f, [2]);
    $c .= '<h2>¿VTV, RTO, ITV o RTV?</h2><p>Son el mismo control con distintos nombres: Verificación Técnica Vehicular (VTV), Revisión Técnica Obligatoria (RTO), Inspección Técnica Vehicular (ITV) o Revisión Técnica Vehicular (RTV). '
        . 'La Ley Nacional de Tránsito 24.449 (art. 34) obliga a la revisión técnica periódica y cada provincia la implementa con su propio sistema.</p>';
    return ['title' => 'VTV, RTO e ITV por provincia: precios y reglas', 'h1' => 'VTV, RTO e ITV en cada provincia',
        'desc' => 'Cómo se llama la verificación técnica en cada provincia, cuánto cuesta, si es obligatoria y dónde hacerla. Las 24 jurisdicciones de Argentina.',
        'cuerpo' => $c];
}

function plantas_indice($D)
{
    $c = '<p class="intro">Listado de plantas de verificación técnica con dirección, horarios y cómo llegar. Los datos salen de los sitios oficiales de cada provincia; cuando no hay listado oficial lo aclaramos.</p>';
    $c .= buscador_plantas();
    $c .= '<h2>Las más buscadas</h2>' . plantas_destacadas($D, 12);
    $c .= anuncio('arriba');
    $por = [];
    foreach (grupos_plantas($D) as $g) $por[$g['provincia']][] = $g;
    foreach ($por as $s => $gs) {
        $p = $D['provincias'][$s];
        $c .= '<section class="grupo-plantas"><h2>' . e($p['sigla']) . ' en ' . e($p['nombre']) . '</h2>';
        if ($s === 'caba') { $c .= '<ul class="localidades"><li>' . enlace(provincia_path($p), 'Ciudad de Buenos Aires') . '<span>' . count($gs[0]['plantas']) . ' plantas</span></li></ul></section>'; continue; }
        $c .= '<ul class="localidades">';
        foreach ($gs as $g) { $n = count($g['plantas']); $c .= '<li>' . enlace($g['path'], $g['nombre']) . '<span>' . $n . ($n === 1 ? ' planta' : ' plantas') . '</span></li>'; }
        $c .= '</ul></section>';
    }
    $sin = array_filter($D['provincias'], function ($p) use ($por) { return !isset($por[$p['slug']]); });
    if ($sin) $c .= '<h2>Otras provincias</h2><p>Todavía no tenemos un listado confiable de plantas para: ' . implode(', ', array_map(function ($p) { return enlace(provincia_path($p), $p['nombre']); }, $sin)) . '. En sus páginas te contamos cómo se hace el trámite.</p>';
    return ['title' => 'Plantas de VTV, RTO e ITV: direcciones y horarios', 'h1' => 'Plantas de VTV, RTO e ITV en Argentina',
        'desc' => 'Dónde hacer la VTV, RTO o ITV: ' . count($D['plantas']) . ' plantas habilitadas en ' . count($por) . ' provincias, por ciudad, con dirección, horarios y cómo llegar.',
        'cuerpo' => $c, 'js' => true];
}

function buscador_plantas()
{
    return '<div class="buscador" id="buscador-plantas"><label for="bp">Buscá tu ciudad o partido</label>'
        . '<input type="search" id="bp" placeholder="Ej.: Rosario, La Plata, Godoy Cruz" autocomplete="off"><p class="bp-vacio" hidden>No encontramos esa localidad. Probá con el partido o la ciudad cabecera.</p></div>';
}

// Ciudades con más plantas, para la portada
// Páginas a impulsar con links internos (las que Google ya muestra en posición 5-20)
function paginas_impulsar()
{
    static $l = null;
    if ($l === null) $l = leer_json(__DIR__ . '/../datos-vtv/impulsar.json', [])['paginas'] ?? [];
    return $l;
}

// Texto de enlace exacto para una página, como la busca la gente
function anchor_mirto($D, $path)
{
    foreach (grupos_plantas($D) as $g) if ($g['path'] === $path) return 'Plantas de ' . $D['provincias'][$g['provincia']]['sigla'] . ' en ' . $g['nombre'];
    foreach ($D['provincias'] as $p) if (provincia_path($p) === $path) return $p['sigla'] . ' en ' . $p['nombre'];
    $fijos = ['/precio-vtv/' => 'Precio de la VTV en cada provincia', '/multa-por-no-tener-vtv/' => 'Multa por no tener la VTV', '/vtv-auto-0km/' => 'VTV de un auto 0 km', '/cuando-vence-la-vtv/' => '¿Cuándo vence la VTV?'];
    return $fijos[$path] ?? null;
}

// Ciudades destacadas: primero las que conviene impulsar, después las que tienen más plantas
function plantas_destacadas($D, $n = 12)
{
    $todas = array_filter(grupos_plantas($D), function ($g) { return $g['provincia'] !== 'caba'; });
    $por_path = [];
    foreach ($todas as $g) $por_path[$g['path']] = $g;
    $orden = [];
    foreach (paginas_impulsar() as $u) if (isset($por_path[$u])) $orden[$u] = $por_path[$u];
    usort($todas, function ($a, $b) { return count($b['plantas']) <=> count($a['plantas']); });
    foreach ($todas as $g) if (!isset($orden[$g['path']])) $orden[$g['path']] = $g;
    $h = '<ul class="localidades">';
    $k = 0;
    foreach ($orden as $g) {
        if (!publicada($g['path'])) continue;
        if ($k++ >= $n) break;
        $c = count($g['plantas']);
        $h .= '<li>' . enlace($g['path'], anchor_mirto($D, $g['path'])) . '<span>' . $c . ($c === 1 ? ' planta' : ' plantas') . '</span></li>';
    }
    return $h . '</ul>';
}
