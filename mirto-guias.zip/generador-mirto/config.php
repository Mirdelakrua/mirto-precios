<?php
/*
 * CONFIGURACIÓN DE MiRTO
 * ----------------------
 * Los precios y datos de cada provincia están en datos-vtv/ (provincias.json y plantas.json).
 * Las claves privadas (API de Claude, bot de Telegram) van en config-local.php.
 */
$config = [

    'sitio_nombre' => 'MiRTO',
    'logo_resalte' => 'RTO',
    'sitio_url' => 'https://mirto.com.ar',
    'sitio_lema' => 'VTV, RTO e ITV en toda Argentina: precios, vencimientos y plantas',
    'email_contacto' => 'contacto@mirto.com.ar',

    // En el servidor el generador vive en /home/USUARIO/generador-mirto y escribe en /home/USUARIO/mirto.com.ar
    'salida' => dirname(__DIR__) . '/mirto.com.ar',
    'datos' => __DIR__ . '/datos',

    // Publicación gradual (las páginas principales salen el primer día)
    'paginas_nuevas_por_dia' => 6,

    'adsense_client' => 'ca-pub-1960935011470846',
    'adsense_slots' => ['arriba' => '', 'medio' => '', 'abajo' => ''],
    'ga4_id' => '',
    'google_site_verification' => '',

    'menu' => [
        '/precio-vtv/' => 'Precios',
        '/cuando-vence-la-vtv/' => '¿Cuándo vence?',
        '/provincias/' => 'Provincias',
        '/plantas/' => 'Plantas',
        '/que-revisan-en-la-vtv/' => 'Qué revisan',
        '/multa-por-no-tener-vtv/' => 'Multas',
        '/noticias/' => 'Noticias',
    ],
    'menu_herramientas' => [
        '/precio-vtv/' => 'Calculadora de precio',
        '/cuando-vence-la-vtv/' => '¿Cuándo vence mi VTV?',
        '/que-revisan-en-la-vtv/' => 'Checklist: ¿pasa mi auto?',
        '/documentacion-para-la-vtv/' => 'Qué llevar a la VTV',
        '/turno-vtv/' => 'Cómo sacar turno',
    ],
    'aviso_legal' => 'MiRTO es un sitio <strong>independiente y no oficial</strong>. Los precios y requisitos los fija cada provincia y pueden cambiar: confirmalos en el sitio oficial antes de ir. Los turnos se sacan sólo en las páginas oficiales.',
    'pie_legal' => 'Sitio informativo independiente. No somos una planta de verificación ni un organismo oficial y no gestionamos turnos. Confirmá siempre precios y requisitos en el sitio oficial de tu provincia.',
    'pie_datos' => 'Datos: resoluciones y sitios oficiales de cada provincia y de las plantas habilitadas.',
    'llms_resumen' => 'Guía argentina independiente sobre la verificación técnica vehicular (VTV, RTO, ITV): precios por provincia y tipo de vehículo, calendario de vencimientos, plantas, requisitos y multas. No es un sitio oficial.',
    'llms_secciones' => [
        '/precio-vtv/' => 'Precio de la VTV en cada provincia', '/cuando-vence-la-vtv/' => 'Cuándo vence la VTV según la patente',
        '/provincias/' => 'VTV, RTO e ITV por provincia', '/plantas/' => 'Plantas de verificación', '/que-revisan-en-la-vtv/' => 'Qué revisan en la VTV',
        '/multa-por-no-tener-vtv/' => 'Multas por no tener la VTV', '/documentacion-para-la-vtv/' => 'Documentación para la VTV', '/noticias/' => 'Noticias de la VTV',
    ],

    // Noticias (categorías propias del sitio)
    'noticias_categorias' => [
        'precios' => ['nombre' => 'Precios y aumentos', 'desc' => 'aumentos de la VTV, RTO e ITV en cada provincia'],
        'controles' => ['nombre' => 'Controles y multas', 'desc' => 'operativos, multas y cambios en las reglas de tránsito'],
        'novedades' => ['nombre' => 'Novedades', 'desc' => 'nuevas plantas, turnos, cambios de requisitos y trámites del auto'],
    ],

    // Links de referido (rel="sponsored", se enmascaran en /ir/clave/). Vacío por ahora.
    'referidos' => [],

    // Revisión semanal de precios con la API de Claude (búsqueda web) y aprobación por Telegram.
    // anthropic_api_key, telegram_token y telegram_chat_id van en config-local.php.
    'anthropic_api_key' => '',
    'ia_modelo' => 'claude-sonnet-5-5',
    'ia_busquedas_max' => 8,
    'revision_precios_dias' => 7,
    'precios_remoto_url' => 'https://raw.githubusercontent.com/Mirdelakrua/mirto-precios/main/precios.json',
    'precios_auto' => true, // los aumentos que pasan los controles se publican solos (sin Telegram)
    'telegram_token' => '',
    'telegram_chat_id' => '',

    'zona_horaria' => 'America/Argentina/Buenos_Aires',
    'modo_prueba' => '',
];

$local = __DIR__ . '/config-local.php';
return is_file($local) ? array_replace($config, (array) require $local) : $config;
